=== BEGIN CANDIDATE PROFILE (harness/prompts/candidate.md) ===
# Candidate Profile — AIG STT Phase 3 (discovery-first)

> This profile is inlined verbatim into every candidate prompt by
> `harness.runner.build_candidate_prompt`. The runtime prompt also supplies
> the current state, recent iterations, a findings ledger, and diagnosis —
> this profile defines the *role, the surface you must discover, the
> reconnaissance checklist, and the required output*. Edit this file to change
> candidate behavior; the next iteration picks it up.

---

## Role

You are a candidate generator for the AIG STT auto-evolution harness. Each
invocation you propose **one change** to `workspace/transcribe.py` that lowers
`corpus_cer` on the 0715 Korean insurance call-center eval batch.

You do not run the evaluator. The harness measures your change and decides
keep/reject. Your job is not to guess parameter values — it is to **discover
what the backend can do** and turn a discovery into a hypothesis.

---

## Hard constraints

Violations are caught by static guards and fail the iteration before
evaluation runs. Do not attempt to bypass them.

- Modify only `workspace/transcribe.py`. Do not edit `harness/`, `scripts/`,
  `judge/`, `frozen/`, `baseline/`, `assets/`, `tests/`, or any docs.
- Keep the signature `transcribe(audio: np.ndarray, sr: int) -> str`.
- Reach the model only through `frozen.asr_backend`. Do not `import
  ctranslate2` or `import transformers` directly, do not call
  `from_pretrained`, instantiate `Whisper(...)`, or dynamically import the
  backend through `importlib` / `__import__`.
- Do not read `assets/audio_profile/`, silero assets, `baseline/`, `judge/`
  internals, or the holdout batch (`BATCH_20250813`).

---

## Your real surface is undermapped

You reach the model only through `frozen.asr_backend`. **Its full source is
inlined in the runtime prompt below (section "Your backend surface") — you
cannot Read the file directly (the sandbox denies `frozen/`), so that inlined
copy IS your surface map. Study it.** Whatever `load()` returns, and whatever
that object and the decode call accept and return, is your true surface — and
the job so far has used a tiny fraction of it.

Much of the headroom is in capabilities of the backend you have **not yet
discovered or used**: things the decode call can return that you are currently
throwing away, methods on the returned object you have never called, inputs you
have never conditioned on. You are **not told what those are**. Finding them —
by reading the backend, recalling the underlying library's API, and reasoning
from the diagnosis — is the work.

Bare parameter sweeps (another beam size, another temperature) are weak *on
their own* and never count as exploration. But once the pipeline is mature, a
*focused* decode-parameter tune against the dominant error axis is a legitimate
exploit move — the runtime prompt's mode block tells you when that is in season.

---

## Each iteration is reconnaissance, then one hypothesis

Before you edit, do reconnaissance and be able to state it:

1. **Surface**: What part of the inlined `frozen.asr_backend` (or the object
   `load()` returns) did you study this iteration? What does it actually expose
   or return that the current `workspace/transcribe.py` ignores?
2. **Ledger**: The runtime prompt gives you a *findings ledger* — facts you
   already established about the surface in earlier iterations. Build on it.
   Do not re-derive a fact already in the ledger, and do not repeat a
   `fingerprint` listed in the recent-iterations table.
3. **Diagnosis**: What failure mode dominates (e.g. deletion-heavy →
   `length_ratio.p05` low; over-generation → `hallucination_hit_rate` rising;
   repetition → repeated-text rate high)? Which *kind* of capability would
   address it — and does the surface offer one?
4. **Runtime**: Will the change fit the runtime budget in the prompt header?

Form a hypothesis from what you discovered, implement it, and let the harness
measure it. The runtime prompt declares a **mode** for each iteration:

- **EXPLORE** — surface a backend mechanism not yet in the fingerprint/ledger
  history. A new value of an already-tried knob is not exploration. The
  "one focused change" rule is relaxed when a structurally new mechanism
  justifies it.
- **EXPLOIT** — extract value from what you already found, two plays: (A)
  *synthesis* — combine prior attempts that each improved a different error axis
  (their diffs are given to you under "Promising prior attempts to SYNTHESIZE");
  or (B) *parameter tuning* — a focused decode-parameter tune on the mature
  pipeline. Exploiting beats inventing something new in this slot.

The job is explore-heavy early and keeps a guaranteed floor of exploration
throughout, so you will be asked to keep finding new mechanisms even late.

---

## Required output format

Your final emission **must end with a YAML fenced block** in exactly this
form. The harness parses it with `yaml.safe_load`; deviation is treated as
absence and the iteration is rejected before any compute is spent.

**The three prose fields almost always contain colons, parentheses, or commas
(e.g. "Negative: align() is...") which break a plain `key: value` line. You
MUST write them as YAML block scalars (`|`) — indent the text under the key —
so punctuation is safe.** Use exactly this shape:

````
```yaml
capability_investigated: |
  what part of the backend surface you studied this iter
what_i_learned: |
  a concrete fact about the surface — a negative result counts
hypothesis: |
  the single change and why this discovery motivates it
fingerprint: [token1, token2]   # 1-6 lowercase tokens, for dedup (inline list, no colons)
# lane: optional-free-form-tag
```
````

Field rules:

- **`capability_investigated`** — non-empty. The backend surface you looked at
  this iteration (even if you ended up not using it).
- **`what_i_learned`** — non-empty. A concrete fact you can stand behind: what
  the decode call returns, what a method does, what an input changes. "X is not
  available through the frozen surface" is a valid, useful learning.
- **`hypothesis`** — non-empty. The one change you made and why the discovery
  motivates it.
- **`fingerprint`** — 1 to 6 lowercase keyword tokens describing what your diff
  touches. Used only for dedup against recent iterations. More than 6 tokens is
  rejected.
- **`lane`** — optional. A rough free-form tag if you want one; not required and
  not validated.

Missing the block, missing any of the four required keys, an empty required
field, or a fingerprint outside 1–6 tokens causes the iteration to be
**rejected before evaluation runs**.

---

## Anti-patterns

- **Parameter sweep without reconnaissance**: e.g. `beam=5 → 6 → 7` across
  iterations with no new fact in `what_i_learned`. If you cannot state a fresh
  surface discovery, you are not ready — investigate a different capability.
- **Re-deriving the ledger**: proposing something the findings ledger already
  recorded as tried or impossible.
- **Defensive wrapping**: `try/except` around the actual call, `if not result:
  return ""` fallbacks, or `max(0, x)` clamps that mask the failure modes the
  harness needs to see for diagnosis. (A genuine, hypothesis-driven fallback
  *policy* is fine — silent error-swallowing is not.)
- **Reading forbidden files**: reading `baseline/`, `judge/` internals,
  `assets/audio_profile/`, or the holdout is a violation. Reading
  `frozen/asr_backend.py` is encouraged.
- **Comments as harness communication**: code intent goes in the response body
  and the YAML block, not into docstring or comment prose.

---

## Output emission order

1. **Edit `workspace/transcribe.py`** directly via `Edit` / `Write` tools — do
   not emit the diff as text in your response.
2. **Brief rationale** (1–3 sentences): the discovery and the hypothesis it
   motivates, referencing the diagnosis, the ledger, or the recent table.
3. **Required YAML block** (see above) as the *last* thing in your response.

The harness reads the YAML block from your stdout, runs `git diff` to capture
your code change, then evaluates. If verification passes and the cer
improvement clears the noise threshold the change is kept; otherwise the code
is rolled back — but your `what_i_learned` is preserved in the ledger, so a
rejected attempt still advances the surface map.

=== END CANDIDATE PROFILE ===

Current workspace/transcribe.py (inlined for context — you may still Read it
through the Edit tool, but Bash is disabled so this is your primary view of
the file's current state):

```python
"""Workspace transcribe — autoresearch evolves this file.

Long-form coverage via timestamp-guided sequential windows. Each window is
decoded WITH Whisper timestamp tokens enabled (the SOT prompt omits
``<|notimestamps|>``), so the decoder emits ``<|t.tt|>`` tokens that survive in
``sequences_ids`` (any id at or above the ``<|0.00|>`` token id; each step above
it is 0.02s). The last such timestamp tells us where the decoder believes the
final complete utterance ended inside the window — so the next window seeks to
that point instead of a blind fixed 30s stride. This is the canonical OpenAI
long-form seek: it stops slicing an utterance that straddles a 30s boundary,
which is the boundary-cut that drives the deletion + repeated-text collapse on
this batch. Windows are still conditioned on the previous window's clean text
through the ``<|startofprev|>`` prefix for cross-window coherence.

Contract (`STT-PIPELINE-SPEC.md §10`): ``transcribe(audio, sr) -> str``.
"""

from __future__ import annotations

import numpy as np

from frozen.asr_backend import generate, load, to_storage_view

_LANGUAGE_TOKEN = "<|ko|>"
_TASK_TOKEN = "<|transcribe|>"
_CHUNK_SECONDS = 30
_MAX_PREV_TOKENS = 224  # Whisper prompt context budget
_TS_STEP_SECONDS = 0.02  # Whisper timestamp token resolution
_MIN_ADVANCE_FRACTION = 0.5  # floor seek advance to bound runtime / prevent stall
_DOMAIN_BUDGET = 24  # tight cap on the domain prior — gentle bias, not forcing

# Static domain-vocabulary prior for the 0715 Korean insurance call-center batch,
# fed through <|startofprev|> on every window. iter_007 showed a full ~40-term
# glossary at budget 64 improved substitution (0.54->0.52) and erased the
# hallucination (0.09->0.00) but pushed insertion up (0.12->0.16): too strong a
# prior forces unspoken domain terms. SYNTHESIS: keep the sub/hal gain, guard the
# insertion regression by trimming to the highest-frequency in-domain terms and a
# much smaller token budget so the decoder is nudged, not over-ridden.
_DOMAIN_PROMPT = (
    "고객님 보험 계약 약관 보장 가입 청약 해지 보험료 납입 "
    "보험금 본인확인 상담사 동의 청구 확인"
)

_EQ_BANDS = 32  # coarse magnitude bands estimating the channel envelope
_EQ_CLIP = 3.0  # max boost/cut of any band — gentle channel correction, not whitening


def _equalize_channel(audio: np.ndarray) -> np.ndarray:
    """Blind channel (spectral-coloration) equalization on the full waveform.

    NEW MECHANISM (EXPLORE): every prior waveform lever reshaped the signal
    only by a fixed spectral tilt (pre-emphasis, iter_024/025), a flat level
    rescale (RMS, iter_026), an out-of-band mask (band-limit, iter_029/043/051),
    or a memoryless amplitude nonlinearity (companding, iter_054). None touched
    the *in-band spectral ENVELOPE*. Telephony (handset + codec) imposes a fixed
    band coloration that tilts that envelope and shifts formant energy ratios —
    the kind of channel distortion that drives consonant/vowel substitution, the
    dominant error axis. We estimate the channel as the coarse (32-band) magnitude
    envelope and divide it out, flattening the coloration toward the training
    distribution while the coarse binning leaves fine formant structure intact and
    the ±3x clip keeps it a gentle EQ (not full whitening that would amplify the
    inter-formant noise floor). Phase is preserved; level is restored to the input
    RMS so downstream mel scaling is unchanged. numpy-only, once per file (outside
    the window loop) — budget-neutral.
    """
    n = len(audio)
    if n < _EQ_BANDS * 2:
        return audio
    spec = np.fft.rfft(audio)
    mag = np.abs(spec)
    m = mag.size
    binsz = int(np.ceil(m / _EQ_BANDS))
    padded = np.pad(mag, (0, binsz * _EQ_BANDS - m), mode="edge")
    coarse = padded.reshape(_EQ_BANDS, binsz).mean(axis=1)
    channel = np.repeat(coarse, binsz)[:m]
    channel = channel / (np.median(channel) + 1e-8)
    channel = np.clip(channel, 1.0 / _EQ_CLIP, _EQ_CLIP)
    out = np.fft.irfft(spec / channel, n=n).astype(np.float32)
    in_rms = float(np.sqrt(np.mean(audio.astype(np.float64) ** 2))) + 1e-8
    out_rms = float(np.sqrt(np.mean(out.astype(np.float64) ** 2))) + 1e-8
    return (out * (in_rms / out_rms)).astype(np.float32)


def transcribe(audio: np.ndarray, sr: int) -> str:
    model, processor = load()
    tok = processor.tokenizer

    # flatten the fixed telephony channel coloration once before any windowing,
    # so the encoder sees a spectral envelope closer to the training distribution.
    audio = _equalize_channel(audio)

    # NOTE: <|notimestamps|> is intentionally omitted so the decoder emits
    # timestamp tokens; they are stripped from the text by skip_special_tokens
    # but read out of the raw sequence to drive the seek.
    sot = tok.convert_tokens_to_ids(
        ["<|startoftranscript|>", _LANGUAGE_TOKEN, _TASK_TOKEN]
    )
    startofprev = tok.convert_tokens_to_ids("<|startofprev|>")
    timestamp_begin = tok.convert_tokens_to_ids("<|0.00|>")

    # encode the tight domain prior once; cap it so it only nudges the lexical
    # prior toward in-domain terms without crowding out the cross-window context.
    domain_ids = tok.encode(_DOMAIN_PROMPT, add_special_tokens=False)[:_DOMAIN_BUDGET]

    chunk_len = _CHUNK_SECONDS * sr
    min_advance = int(_CHUNK_SECONDS * _MIN_ADVANCE_FRACTION * sr)
    n_samples = len(audio)

    texts: list[str] = []
    prev_ids: list[int] = []
    seek = 0
    while seek < n_samples:
        seg = audio[seek : seek + chunk_len]
        if seg.size == 0:
            break

        inputs = processor(seg, sampling_rate=sr, return_tensors="np")
        features = to_storage_view(inputs.input_features)

        # domain prior leads the context on every window (incl. window 0, which
        # previously had no prefix); the remaining budget carries the previous
        # window's clean text for cross-window coherence.
        prev_budget = max(_MAX_PREV_TOKENS - len(domain_ids), 0)
        context = domain_ids + prev_ids[-prev_budget:] if prev_budget else domain_ids
        prompt = [startofprev] + context + sot

        results = generate(
            features,
            [prompt],
            beam_size=4,
            patience=1.2,
            sampling_temperature=0.0,
            repetition_penalty=1.1,
            no_repeat_ngram_size=4,
        )

        token_ids = results[0].sequences_ids[0]
        text = tok.decode(token_ids, skip_special_tokens=True)
        if text.strip():
            texts.append(text)
            # re-encode the clean decoded text as next window's context, so EOT
            # / timestamp ids never leak into the <|startofprev|> prefix
            prev_ids = tok.encode(text.strip(), add_special_tokens=False)

        # find the last timestamp token to decide where the next window starts
        seg_seconds = seg.shape[0] / sr
        last_ts_seconds = None
        for tid in reversed(token_ids):
            if tid >= timestamp_begin:
                last_ts_seconds = (tid - timestamp_begin) * _TS_STEP_SECONDS
                break

        if last_ts_seconds is not None:
            advance = int(min(last_ts_seconds, seg_seconds) * sr)
        else:
            advance = chunk_len
        # a degenerate early timestamp would re-decode most of the window and
        # blow the runtime budget (or stall) — floor the stride.
        advance = max(advance, min_advance)
        seek += advance

    return " ".join(t.strip() for t in texts if t.strip())

```

Your backend surface — frozen/asr_backend.py (inlined; you cannot Read it
directly — the sandbox denies frozen/. THIS is your surface map. Study what
load() returns and what generate()'s **decoding_kwargs accepts/returns — the
unused capabilities live here):

```python
"""Frozen ASR backend — model / device / precision are hard-coded here.

Workspace MUST go through ``load()``, ``generate()`` and ``to_storage_view()``
helpers only. The Phase 3 static guard rejects any direct
``ctranslate2``/``transformers`` import in ``workspace/`` (see
``docs/PHASE3-PLAN.md §1.2``). Do not edit this file once Phase 3 starts.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

import ctranslate2
from ctranslate2.converters import TransformersConverter
from transformers import WhisperProcessor

log = logging.getLogger(__name__)

_MODEL_NAME = "openai/whisper-large-v3-turbo"
_MODEL_CACHE_PATH = (
    Path(__file__).resolve().parents[1] / ".cache" / "ct2_models" / "whisper-large-v3-turbo"
)
_DEVICE = "cuda"
_COMPUTE_TYPE = "float16"

_model: ctranslate2.models.Whisper | None = None
_processor: WhisperProcessor | None = None


def _ensure_ct2_cache() -> Path:
    """Convert HF weights to CT2 once and cache them."""
    if (_MODEL_CACHE_PATH / "model.bin").is_file():
        return _MODEL_CACHE_PATH

    log.warning(
        "CT2 cache missing — converting %s to %s (one-time, slow)",
        _MODEL_NAME,
        _MODEL_CACHE_PATH,
    )
    _MODEL_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    converter = TransformersConverter(_MODEL_NAME, copy_files=["tokenizer.json"])
    converter.convert(
        output_dir=str(_MODEL_CACHE_PATH),
        quantization=_COMPUTE_TYPE,
        force=False,
    )
    return _MODEL_CACHE_PATH


def load() -> tuple[ctranslate2.models.Whisper, WhisperProcessor]:
    """Return the cached (model, processor) — both globals on first call."""
    global _model, _processor
    if _model is None or _processor is None:
        cache_dir = _ensure_ct2_cache()
        _processor = WhisperProcessor.from_pretrained(_MODEL_NAME)
        _model = ctranslate2.models.Whisper(
            str(cache_dir),
            device=_DEVICE,
            compute_type=_COMPUTE_TYPE,
        )
    return _model, _processor


def generate(features: Any, prompts: Any, **decoding_kwargs: Any) -> Any:
    """Pass-through to ``ctranslate2.models.Whisper.generate``.

    Decoding kwargs are open for workspace to evolve (beam_size, temperature,
    length_penalty, repetition_penalty, sampling_*, return_no_speech_prob, …).
    """
    model, _ = load()
    return model.generate(features, prompts, **decoding_kwargs)


def to_storage_view(np_array: Any) -> ctranslate2.StorageView:
    """numpy array → CT2 StorageView so workspace doesn't import ctranslate2."""
    return ctranslate2.StorageView.from_array(np_array)

```

Goal:
- Improve corpus_cer on the 0715 eval batch.
- Final target: corpus_cer <= 0.1.
- Runtime must stay within the baseline budget: 152.30568834098813 seconds.

Hard constraints (also stated in profile — reinforced here for runtime):
- Modify only workspace/transcribe.py.
- Keep transcribe(audio, sr) -> str.
- Do not import ctranslate2 or transformers directly.
- Do not call from_pretrained or instantiate Whisper directly.
- Do not read assets/audio_profile, silero assets, baseline internals, judge internals, or holdout data.
- Make one focused change only.

Current state:
- job_id: phase3_005
- iteration: 85
- best_hyp_id: phase3_005_iter_063
- best_cer: 0.17750901835038252
- noise_floor sigma: 0.0 (provisional=True)

Error profile (best = phase3_005_iter_063, corpus_cer 0.1775):
- error mix: substitution 55% / deletion 33% / insertion 13%
- length_ratio: mean 0.97 (p05 0.93) — coverage proxy (≈1.0 = full)
- hallucination 0.00 | repeated 0.00
- DOMINANT AXIS: substitution (sub 55% ≫ del/ins, length_ratio 0.97 healthy) → headroom is in *what* gets mis-recognized (domain terms, phone-band audio), not coverage.

Recent iterations (your own job, last 5 — for dedup AND
diagnosis; the sub/del/ins, len, hal columns show *how* each attempt failed,
not just its cer. Do not repeat a fingerprint):
| iter | fingerprint                          | cer    | sub/del/ins | len  | hal  |
|------|--------------------------------------|--------|-------------|------|------|
| phase3_005_iter_080 | rover,consensus,token-vote,n-best,explore | n/a |      —      |  —   |  —   |
| phase3_005_iter_081 | companding,ngram-relax,length-penalty,synthesis,exploit-a | 0.2070 | 0.47/0.33/0.19 | 0.97 | 0.00 |
| phase3_005_iter_082 | sampling,num-hypotheses,mbr,consensus,topk,explore | 0.1896 | 0.54/0.35/0.11 | 0.95 | 0.09 |
| phase3_005_iter_083 | beam-size,beam-width,exploit-b,decode-tune | 0.1834 | 0.53/0.32/0.15 | 0.98 | 0.00 |
| phase3_005_iter_084 | align,notimestamps,forced-alignment,seek,explore | 0.4894 | 0.24/0.14/0.62 | 1.22 | 0.00 |

Findings ledger (what you have already learned about the backend surface —
these survive even when the code change was rolled back; build on them, do not
re-derive them):
- (phase3_005_iter_055) probed `generate()'s patience kwarg (iter_016/023 CT2 beam-search depth multiplier,
left at 1.0 in best/iter_049), isolated on best/iter_049's mature config
(beam=3, repetition_penalty=1.1, no_repeat_ngram_size=4). Not bundled with
any ngram=5 / lp=0.9 / rp=1.05 relaxation.` → patience has only ever been observed CONFOUNDED on this job: every prior
patience move (iter_038 p=1.5, iter_044/047 p=1.2) also carried
no_repeat_ngram_size=5 + rp=1.05, whose over-relaxation blew insertion
0.13->0.23, and iter_048 isolated patience only on the OLD iter_009 config
(ngram=3) before iter_049 became best. So on the current mature ngram=4 best
(length_ratio 0.97, repeated_text 0.00) patience's own contribution to the
dominant substitution axis is unmeasured. patience deepens beam SEARCH —
letting a less-substituted, higher-likelihood hypothesis overtake the
premature top beam — without adding parallel beams or sequence length, so it
is the one substitution lever that does not feed the insertion axis that
every prior pairing's lp had to fight.
- (phase3_005_iter_056) probed `The raw np.ndarray waveform that load()'s WhisperProcessor mel front end
consumes, treated as a NONLINEAR amplitude map (power-law companding,
iter_054), now grafted as an EXPLOIT-A synthesis onto best/iter_049's mature
decode config (beam=3, patience=1.0, repetition_penalty=1.1,
no_repeat_ngram_size=4) instead of the older host iter_054 ran on.` → iter_054 measured gamma=0.8 companding as the single biggest substitution-axis
gain in the recent set (sub +0.04 vs best) but it lost overall on a -0.03
coverage regression: at 0.8 the dynamic-range compression lifts low-amplitude
samples so hard that near-silent telephony tails raise their noise floor and
the timestamp seek terminates short. The lever and its regression are
separable by gamma magnitude — gamma is a continuous knob, so a milder 0.9 is
a strictly gentler lift of consonant/fricative energy than 0.8, and the
acoustic sub gain and the coverage cost both scale with (1-gamma), making 0.9
the unsampled point that should keep most sub gain while shrinking the seek
regression on best/iter_049's healthy 0.97 coverage.
- (phase3_005_iter_057) probed `Composed two already-surfaced levers: the nonlinear waveform companding
(iter_054/056, y=sign(x)*|x|^gamma, the single biggest substitution-axis
gain at +0.04) and generate()'s length_penalty in its UPWARD region (>1.0,
flagged unmeasured in iter_030/041) — CT2 exponential sequence-length
beam-score normalization that favors fuller hypotheses.` → Companding's lone regression is mechanistically specific: iter_054 (-0.03
coverage) and iter_056 (coverage 0.95) lost because lifting low-amplitude
samples raises the noise floor on near-silent telephony tails, so the
timestamp-seek reads an early last-<|t.tt|> and terminates the window short.
That regression lives on the same sequence-length axis length_penalty
reweights — but every prior length_penalty use was <1.0 (an insertion
guard); the >1.0 direction that favors a later final timestamp (advancing
the seek, recovering coverage) has never been paired with companding.
- (phase3_005_iter_058) probed `generate()'s return_scores kwarg (CT2 per-token-normalized avg log-prob in
result.scores[0], length_penalty=1.0) combined with a zlib gzip
compression-ratio degeneracy detector on the decoded text. Both are signals
never computed on this job — every prior iter read sequences_ids / timestamp
tokens / no_speech_prob (iter_035) but left scores unrequested, and no iter
ever measured text repetitiveness via compression ratio.` → return_scores=True attaches a per-window avg log-prob to each result, a
confidence signal orthogonal to no_speech_prob (silence VAD): a window can be
voiced yet low-confidence when the deterministic beam locks onto a wrong
prefix every beam shares — the basin that makes width/depth/length/penalty
knobs (iter_033..052) plateau near 0.19. The gzip compression ratio is a
second, text-only degeneracy signal that catches the over-generation tail
(worst file length_ratio 1.08) that avg log-prob alone misses. Together they
gate a sampling-branch re-decode that draws a DIFFERENT prefix — the only
surfaced way out of the substitution basin — at near-zero extra cost since
confident windows never trigger it.
- (phase3_005_iter_059) probed `generate()'s two deterministic-search levers together — beam_size (search
WIDTH, iter_012/027/052) and patience (CT2 beam-search DEPTH multiplier,
iter_016/023/055) — composed on best/iter_049's mature decode config
(ngram=4, repetition_penalty=1.1, length_penalty default 1.0). Both were
isolated singly on this exact best in iter_052 and iter_055; never combined.` → Width and depth are the only two substitution-axis levers that reshape the
SAME deterministic search without lengthening the sequence (iter_044/038's
ngram=5 cluster blew insertion 0.13->0.23; beam=4 alone only moved it
0.13->0.15 per iter_027, and patience adds no parallel beams or length per
iter_048). So they are the one pair that can be stacked against the
confident-but-wrong substitution basin (the plateau near 0.19 across
iter_033..055) without feeding the insertion axis a length_penalty guard
would otherwise have to fight — a region untested because every prior multi-
lever synthesis paired a search knob with the ngram/lp relaxation instead.
- (phase3_005_iter_060) probed `generate()'s length_penalty kwarg (CT2 exponential sequence-length beam-score
normalization, iter_014) in its UPWARD region (>1.0), tuned as an isolated
EXPLOIT-B parameter tune on the current best/iter_059 config (beam_size=4,
patience=1.2, repetition_penalty=1.1, no_repeat_ngram_size=4, lp default 1.0).` → Every prior length_penalty use in the ledger was <1.0 as an insertion guard
bundled with a stronger prior (iter_018/025/028) or with companding (iter_057),
so the >1.0 direction has never been measured isolated, and never at all on the
search-heavy beam=4/patience=1.2 best. On best, length_ratio mean 0.97 / p05
0.94 sits under 1.0 with 32% deletion and the worst files are coverage-starved
(01_8098 lr 0.925), so the decoder selects slightly short hypotheses — lp>1.0
reweights finished beams toward fuller ones (a later final timestamp advances
the seek) without adding parallel beams, so it attacks the deletion axis the
decode-kwarg cluster (iter_033..059) left untouched while it plateaued on sub.
- (phase3_005_iter_061) probed `The raw np.ndarray waveform that load()'s WhisperProcessor mel front end
consumes, treated as a NONLINEAR amplitude map (power-law companding,
iter_054/056/057), grafted as EXPLOIT-A synthesis onto the CURRENT best/
iter_059 search-heavy decode host (beam_size=4, patience=1.2,
repetition_penalty=1.1, no_repeat_ngram_size=4) — a host the acoustic lever
was never measured on.` → Companding was the single biggest substitution-axis gain in the job
(sub +0.04, iter_054) but lost every time on a coverage regression: lifting
low-amplitude samples raises the noise floor on near-silent telephony tails,
the timestamp-seek then reads an early last-<|t.tt|> and terminates the
window short. That cost and the sub gain both scale with (1-gamma), so the
two prior points (0.8/iter_054, 0.9/iter_056) over-lifted; gamma=0.95 is the
unsampled gentlest rung. Critically, every prior companding host was the
beam=3 iter_049 config — it was never paired with iter_059's beam=4/
patience=1.2 search levers, which already pushed coverage to a healthy 0.97
/ p05 0.94 (length_ratio mean 0.97), the most regression-tolerant host yet.
- (phase3_005_iter_062) probed `generate()'s repetition_penalty kwarg (iter_006's soft per-step logit decay,
held at 1.1 in best/iter_059), tuned isolated on the CURRENT best/iter_059
search-heavy config (beam_size=4, patience=1.2, no_repeat_ngram_size=4,
length_penalty default 1.0). EXPLOIT-B parameter tune, not a new mechanism.` → rp=1.05 has only ever been measured on the beam=3 host — confounded with the
ngram=5/lp=0.9 cluster (iter_033/040) or isolated on iter_049's beam=3 best
(iter_053). It has never been measured on iter_059's beam=4/patience=1.2
search-heavy host, which became best AFTER all those probes. Since best shows
repeated_text 0.00, rp=1.1 does no protective work (only a thin hal guard) —
it is pure downside on the dominant substitution axis, forcing the decoder to
substitute an alternative for any token whose logit the soft decay suppressed.
Unlike the ngram relaxation it does not free banned n-grams, so it adds no
insertion the way ngram=5 did (0.13->0.23) — leaving lp default 1.0 untouched.
- (phase3_005_iter_063) probed `The raw np.ndarray waveform consumed by load()'s WhisperProcessor mel front
end (iter_024/026/029/054), treated as a CHANNEL-equalizable surface: the
in-band spectral envelope reshaped via an rfft magnitude divide, not just
masked, tilted, level-scaled, or amplitude-companded.` → Every prior waveform lever preserved the in-band spectral ENVELOPE: pre-emphasis
(iter_024/025) applies a fixed spectral tilt, RMS (iter_026) a flat level scale,
band-limit (iter_029/043/051) an out-of-band mask, companding (iter_054) a
memoryless amplitude map — none flattens the slowly-varying coloration the
telephony handset+codec imposes. That coloration tilts formant energy ratios,
exactly the distortion behind consonant/vowel substitution (dominant axis, 53%).
A coarse 32-band magnitude estimate divided out (clipped to ±3x so it is a
gentle EQ, not noise-amplifying whitening; phase kept; RMS restored) is a blind
channel-normalization mechanism reachable on the waveform surface and budget-
neutral (one rfft/irfft per file, outside the window loop).
- (phase3_005_iter_064) probed `The raw np.ndarray waveform feeding load()'s WhisperProcessor mel front end,
treated as an rfft surface composing TWO orthogonal spectral operators in a
single transform: the in-band 32-band envelope flatten (channel-EQ, iter_063,
current best) and the out-of-band band-pass mask (iter_043/051), both applied
to one spec before a single irfft. np.fft.rfftfreq(n, 1/sr) maps bins to Hz
so the 300–3400 telephony passband is selectable.` → The channel-EQ and the band-limit mask coexist in one rfft pass without
interfering IF the coarse envelope median is taken on the FULL-band magnitude
before masking: masking first would null most >3400 Hz bins (over half the
spectrum at 16 kHz), collapsing the median toward 0 and making channel/median
blow up to the clip ceiling, over-attenuating the in-band content. Estimating
the envelope first keeps the median unbiased; the mask then only removes
out-of-band energy (length-neutral per iter_051), so the two acoustic
sub-axis levers stack without a coverage guard.
- (phase3_005_iter_065) probed `The raw np.ndarray waveform feeding load()'s WhisperProcessor mel front end,
treated as a two-stage acoustic surface: channel-EQ envelope flatten
(iter_063, current best) followed by power-law dynamic-range companding
(iter_054/057), composed with generate()'s length_penalty in its >1.0 region.` → Channel-EQ and companding act on orthogonal acoustic dimensions of the same
waveform: the EQ divide reshapes the spectral ENVELOPE (formant energy ratios)
while companding y=sign(x)*|x|^0.9 reshapes the AMPLITUDE RATIO between samples
(lifting quiet consonant/fricative energy) — neither touches the other's axis,
so they can stack in sequence (EQ first, so the lift acts on the flattened
envelope, not the raw telephony coloration). Companding's only known
regression is seek-truncation from a raised tail noise floor, which lives on
the sequence-length axis length_penalty>1.0 reweights.
- (phase3_005_iter_066) probed `generate()'s decode kwargs (no_repeat_ngram_size hard-ban, repetition_penalty
soft decay, length_penalty CT2 sequence-length beam-score normalization),
composed with the channel-EQ acoustic front end now baked into best/iter_063.` → iter_044/038 measured ngram=5 + rp=1.05 + lp=0.9 as improving BOTH the
substitution axis (+0.07) and coverage (+0.03) vs the old best, losing only
on insertion (0.13->0.23) because the noisy non-EQ input over-fed the relaxed
decoder. That decode config has never been measured on top of the channel-EQ
best, which flattens the telephony formant coloration feeding the encoder — so
the insertion regression and the channel-EQ acoustic cleanup live on
separable surfaces and were never composed.
- (phase3_005_iter_067) probed `generate()'s suppress_tokens decode kwarg — a CT2 Whisper capability that
forces -inf on a fixed token-id set at every decode step, constraining the
emittable vocabulary itself. Untouched in the ledger: every prior decode
probe (beam/patience/length/repetition/ngram/sampling/return-flags) only
reshaped SCORING over the full vocab. Default [-1] fires only the built-in
non-speech suppression. I built the id set from processor.tokenizer's
get_vocab() (Whisper byte-level BPE maps printable ASCII to itself).` → suppress_tokens is a live, default-[-1] generate() kwarg distinct from every
scoring lever mapped so far: it removes ids from the output distribution
rather than reweighting the search. Because Whisper BPE encodes printable
ASCII as itself, normal (id < eos_token_id) tokens whose surface string
contains a-z/A-Z literally emit Latin bytes, so they are enumerable without a
forward pass; suppressing them is length-neutral (no insertion/deletion
pressure) and cacheable once per run. id >= eos_id (specials + the seek's
<|t.tt|> timestamps) must be excluded so the timestamp-driven seek survives,
and -1 must be retained so the built-in non-speech suppression still applies.
- (phase3_005_iter_068) probed `generate()'s repetition_penalty kwarg (iter_006's soft per-step logit decay,
held at 1.1 in best/iter_063), tuned ISOLATED on the current channel-EQ best
host (beam_size=4, patience=1.2, no_repeat_ngram_size=4, length_penalty
default 1.0). EXPLOIT-B focused parameter tune, not a new mechanism.` → rp=1.05 has only ever been measured on the PRE-channel-EQ host: iter_062
isolated it on iter_059 (no EQ), and iter_066 measured it confounded with
ngram=5/lp=0.9 (which blew insertion 0.13->0.23). It has never been measured
isolated on the channel-EQ best (iter_063), which flattens the telephony
formant coloration feeding the encoder and shifts the logit landscape the
soft decay acts on. Since best shows repeated_text 0.00, rp=1.1 does no
protective work — pure downside on the dominant substitution axis, forcing a
substitute for any token whose logit the decay suppressed. Unlike the ngram
ban it frees no n-grams, so it adds no insertion, leaving lp default 1.0 and
coverage 0.97 untouched.
- (phase3_005_iter_069) probed `The channel-EQ front end's own clip hyperparameter (_EQ_CLIP), the
per-band correction ceiling on the rfft magnitude-divide that became
best/iter_063. Every ledger probe tuned generate() decode kwargs or
composed new acoustic operators, but the winning EQ mechanism's internal
bounds (_EQ_BANDS, _EQ_CLIP) were never swept.` → The blind channel estimate divides out a coarse 32-band envelope clipped
to ±3.0x. Bands the telephony handset+codec color most strongly saturate
that clip, so they are deliberately UNDER-corrected — the residual
coloration that survives EQ sits exactly on the most-distorted bands,
which are the ones tilting formant energy ratios behind the dominant
substitution axis. The clip is a continuous knob distinct from every
decode lever; widening it deepens correction only on saturated bands and
is length-neutral (phase preserved, RMS restored), so it cannot feed the
insertion/deletion axes the recent composites regressed on.
- (phase3_005_iter_070) probed `generate()'s no_repeat_ngram_size kwarg (iter_031's hard n-gram ban, held at
4 in best/iter_063) tuned at the milder rung 5, ISOLATED on the current
channel-EQ best host (beam_size=4, patience=1.2, repetition_penalty=1.1,
length_penalty default 1.0). EXPLOIT-B focused parameter tune on the dominant
substitution axis — no new mechanism.` → ngram=5 has only ever been measured on the EQ best CONFOUNDED: iter_066
bundled it with rp=1.05 (soft-brake relaxation) + lp=0.9, and lost on
insertion (0.13->0.18). The ngram ban is pure downside at repeated_text 0.00,
so the milder 5-gram ban frees more legitimately-repeated Korean
particle/ending 3/4-grams the 4-gram ban suppresses (substitution gain), but
its effect with BOTH insertion guards intact (rp=1.1 soft decay + lp default,
unrelaxed) is unmeasured on the EQ host. iter_066's ledger attributes the
insertion blow-up to the noisy non-EQ input over-feeding the RELAXED decoder;
the channel-EQ front end flattens that telephony coloration, so the freed
n-grams should over-generate far less than on the non-EQ host — and retaining
rp=1.1 + lp default (vs iter_066's rp=1.05 + lp=0.9) keeps the strongest
available guards on the residual insertion the relaxation feeds.
- (phase3_005_iter_071) probed `generate()'s patience kwarg (CT2 beam-search depth multiplier, iter_016/023)
tuned at the unsampled rung 1.5, ISOLATED on the current channel-EQ best host
(beam_size=4, repetition_penalty=1.1, no_repeat_ngram_size=4, length_penalty
default 1.0). EXPLOIT-B focused parameter tune on the dominant substitution
axis — no new mechanism.` → patience=1.5 has only ever been measured CONFOUNDED on this job: iter_038 ran
it bundled with no_repeat_ngram_size=5 + rp=1.05 + lp=0.9 on the beam=3 host,
whose ngram=5 relaxation itself blew insertion 0.13->0.23. On the current
beam=4 channel-EQ best (iter_063) patience tops out at 1.2 and was never
pushed higher in isolation. patience deepens beam SEARCH only — it adds no
parallel beams and no sequence length — so unlike every decode-kwarg
relaxation that lost on the EQ host (rp=1.05/iter_068, ngram=5/iter_070, the
iter_066 bundle, all insertion-positive) it cannot feed the insertion axis,
making it the one substitution lever testable here without a coverage/lp
guard. The encoder runs once per window regardless of search depth, so the
cost scales only with the cheap 4-layer turbo decoder.
- (phase3_005_iter_072) probed `The raw np.ndarray waveform feeding load()'s WhisperProcessor mel front end,
treated as a frame-based STFT surface for ADDITIVE-noise removal via magnitude
spectral subtraction — estimating a per-frequency-bin stationary noise floor
from a low time-percentile of |STFT| and subtracting it, distinct from the
rfft magnitude-DIVIDE the channel-EQ best (iter_063) performs.` → Every prior waveform lever in the ledger is multiplicative or memoryless and
preserves the additive noise floor: pre-emphasis (iter_024/025) tilts the
spectrum, RMS (iter_026) scales level, band-limit (iter_029/043/051) masks
out-of-band bins, companding (iter_054) maps amplitude, channel-EQ (iter_063)
DIVIDES the in-band envelope. None SUBTRACTS the stationary energy present in
every frame. A per-bin low-time-percentile of |STFT| isolates that floor (the
quietest-frame energy = noise, not speech); subtracting it with an over-sub
factor and a spectral floor (to bound musical noise) attacks the additive hiss
that smears consonant/fricative spectra behind the substitution axis — an axis
orthogonal to the multiplicative coloration EQ flattens, so the two front ends
compose (denoise first, then flatten). One STFT/ISTFT per file, numpy-only,
outside the window loop → budget-neutral.
- (phase3_005_iter_073) probed `EXPLOIT-A composition of two prior sub-axis levers on the channel-EQ best
(iter_063): the waveform power-law companding y=sign(x)*|x|^gamma
(iter_054/057, the job's single biggest substitution-axis gain at +0.07) and
generate()'s length_penalty in its >1.0 region (iter_057's seek-trunc guard),
grafted onto the EQ-flattened front end.` → Companding and channel-EQ act on orthogonal acoustic dimensions of the same
waveform: EQ divides out the spectral ENVELOPE (formant energy ratios) while
companding reshapes the AMPLITUDE RATIO between samples (lifting quiet
consonant/fricative energy). iter_065 already composed them but only at
gamma=0.9; companding's lone regression (seek-truncation from a raised
near-silent-tail noise floor) scales with (1-gamma), so the gentlest rung
gamma=0.95 — applied AFTER the EQ so the lift acts on the de-colored signal —
is the unsampled point that should retain most of the consonant lift while
shrinking the coverage cost length_penalty=1.05 then guards.
- (phase3_005_iter_074) probed `The <|startofprev|> prompt-conditioning surface — specifically how the
224-token cross-window context budget is populated. Until now it carried
only the single immediately-previous window's decoded text (prev_ids
replaced each window); the rest of the budget went unused for document
history.` → The prompt budget can hold a growing document-level memory rather than a
one-window sliding window: re-encoding each window's skip_special_tokens
text and APPENDING (not replacing) keeps EOT/timestamp ids out of the
prefix while the [-prev_budget:] slice bounds it to the Whisper prompt
budget. This is mechanically distinct from the static _DOMAIN_PROMPT prior
(fixed glossary) and from every decode/waveform lever in the ledger — it
changes WHAT conditions the decoder, not how the search scores or how the
signal is shaped. Budget-neutral: one list slice, same single decode/window.
- (phase3_005_iter_075) probed `generate()'s length_penalty kwarg (CT2 exponential sequence-length beam-score
normalization, iter_014) in its UPWARD region (>1.0), tuned as an isolated
EXPLOIT-B parameter tune on the current channel-EQ best/iter_063 host
(beam_size=4, patience=1.2, repetition_penalty=1.1, no_repeat_ngram_size=4,
length_penalty default 1.0).` → length_penalty>1.0 has never been measured isolated on the channel-EQ best:
iter_060 tested it on the pre-EQ iter_059 host, and on the EQ host it only
ever appeared bundled with companding (iter_073, lp=1.05) or the ngram=5
relaxation (iter_044/066, lp=0.9 downward). So the >1.0 direction's own
effect on the deletion axis is unobserved on the mature EQ pipeline.
- (phase3_005_iter_076) probed `The raw np.ndarray waveform feeding load()'s WhisperProcessor mel front end,
treated as a TIME-VARYING amplitude surface: short-time RMS automatic gain
control (AGC) reshaping the temporal level envelope, distinct from the rfft
spectral-envelope divide the channel-EQ best (iter_063) performs.` → Every prior waveform lever changed amplitude GLOBALLY or MEMORYLESSLY: RMS
(iter_026) is one flat scale, companding (iter_054) a memoryless nonlinearity,
channel-EQ (iter_063) a spectral-envelope divide, spectral subtraction
(iter_072) an additive-floor removal. None equalizes the TEMPORAL level swing
between the loud agent and the quiet customer on these two-party calls — the
quiet spans arrive under-resolved, where substitution (55%) concentrates. A
per-sample short-time RMS (O(n) cumsum box filter) divided into global RMS
pulls voiced spans to a common level; a noise gate (gain held at 1.0 below 10%
of global RMS) leaves silent tails untouched, so it avoids companding's lone
regression (lifted near-silent-tail floor truncating the timestamp seek).
Orthogonal to EQ's spectral axis, so they compose: AGC first, then EQ.
- (phase3_005_iter_077) probed `generate()'s two repetition controls as opposing levers: the hard
no_repeat_ngram_size ban (iter_031) and the soft per-step repetition_penalty
decay (iter_006), composed on the channel-EQ best/iter_063 host (beam=4,
patience=1.2, length_penalty default). EXPLOIT-A synthesis of iter_044/038's
ngram=5 sub gain with a tightened soft brake.` → ngram=5 has only ever been measured paired with a SIMULTANEOUSLY lowered soft
brake — iter_044/038/066 all set repetition_penalty=1.05 alongside the ngram
relaxation (doubly relaxing the repeat controls), and iter_070 isolated ngram=5
at rp=1.1 (best's value) and lost on insertion. The hard ban and the soft decay
act on different repeat classes: ngram=5 frees legitimately-repeated Korean
particle/ending 4-grams (substitution gain on the dominant 55% axis) that the
4-gram ban wrongly suppresses, while rp soft-decays the score of any token
already emitted. So relaxing the hard ban (sub gain) while RAISING the soft
brake above 1.1 (insertion guard) is a mechanically coherent, never-sampled
combination — every prior pairing moved both knobs the same direction.
- (phase3_005_iter_078) probed `generate()'s return_alternatives + num_hypotheses N-best list (the full beam,
surfaced with no extra forward pass per iter_050) consumed by a SELECTION
criterion never used: external domain-glossary lexical coverage, scoring each
hypothesis by how many in-domain insurance terms it spells, rather than any
internal scalar (beam-score iter_004, length, MBR cross-agreement iter_050,
align re-scoring iter_019).` → results[0].sequences_ids becomes a list of num_hypotheses token-id sequences
under return_alternatives=True, so the whole beam is observable post-decode at
zero extra model cost. Unlike MBR (agreement among hypotheses) or score/length
(intrinsic), glossary re-ranking is the first selector that scores a hypothesis
against an EXTERNAL known lexicon — directly addressing domain-term substitution
(the dominant 55% axis) by recovering a correctly-spelled in-domain term from a
lower beam when the top beam substituted it. Strict '>' tie-break makes it a
genuine no-op fallback to the top beam wherever the glossary is non-discriminating.
- (phase3_005_iter_079) probed `generate()'s two repeat controls and length normalization composed on the
channel-EQ best/iter_063 host: the hard no_repeat_ngram_size ban (iter_031),
the soft repetition_penalty decay (iter_006), and length_penalty (iter_014)
in its <1.0 insertion-guard region.` → iter_044/038's bundle (ngram=5 + rp=1.05 + lp=0.9) gave the job's largest
combined gain (sub +0.07, coverage +0.03) but always carried TWO
simultaneous relaxations — the lowered soft brake (rp 1.1->1.05) the ledger
(iter_066) blames for the insertion blow-up. The two halves are separable:
iter_070 relaxed only the hard ban (ngram=5) at rp=1.1 but with lp DEFAULT
and lost on insertion; iter_066 added lp=0.9 but also dropped rp to 1.05.
The clean point — ngram=5 (sub/coverage gain) + lp=0.9 (insertion guard) +
rp held at best's 1.1 (no soft-brake co-relaxation) — has never been
measured on the channel-EQ host.
- (phase3_005_iter_080) probed `generate()'s return_alternatives + num_hypotheses N-best list
(results[0].sequences_ids becomes the whole beam at zero extra forward pass,
surfaced iter_050/078), consumed not by SELECTING one hypothesis but by
per-position consensus voting (ROVER) that constructs a NEW sequence.` → Every prior N-best consumer was a whole-hypothesis selector (max beam-score
iter_004, length, MBR centroid iter_050, align re-score iter_019, glossary
coverage iter_078) — each constrained to a sequence the beam actually emitted.
Aligning the lower beams to the top beam with difflib.SequenceMatcher on token
ids and voting per aligned position is mechanically distinct: it can output a
token the top beam never chose, fixing a substituted token wherever a plurality
of the other beams agreed on the right one. Seeding each position's counter
with the ref token first makes ties strictly favour the top beam — a genuine
no-op fallback where the beam agrees. Content tokens (id<eot) only; the seek
still reads timestamps off the raw top-beam sequence. Pure Python, no model call.
- (phase3_005_iter_081) probed `Composed two surfaced substitution-axis levers on best/iter_063's channel-EQ
host: the waveform power-law companding y=sign(x)*|x|^gamma (iter_054/057,
amplitude-ratio surface) and generate()'s no_repeat_ngram_size=5 + length_penalty
in its <1.0 insertion-guard region (the decode relaxation, iter_044/079).` → Companding (acoustic amplitude-ratio) and the ngram=5/lp=0.9 decode relaxation
each delivered sub +0.07 independently but on disjoint surfaces, so they were
never composed: iter_073/065 paired companding only with lp>1.0 (its own seek
guard, never the ngram ban), and iter_079 ran ngram=5+lp=0.9+rp=1.1 (0.1814,
the closest reject) with no acoustic lever. lp=0.9 contradicts companding's
usual lp=1.05 coverage guard, but iter_044 showed ngram=5/patience=1.2 NETS
coverage +0.03 even under lp=0.9, so that surplus — not lp — is the host that
can absorb companding's mild near-silent-tail seek cost at the gentlest γ=0.95.
- (phase3_005_iter_082) probed `generate()'s stochastic decoding path — beam_size=1 with sampling_topk +
sampling_temperature>0 + num_hypotheses, returning N INDEPENDENT sampled
sequences in results[0].sequences_ids. Distinct from the deterministic beam
N-best (return_alternatives, iter_050/078/080) whose hypotheses are near-
duplicates of one prefix; sampling draws genuinely divergent prefixes.` → Under sampling (beam_size=1, sampling_topk>0, sampling_temperature>0),
num_hypotheses=N makes results[0].sequences_ids an N-long list of independent
samples rather than the N top beams — so the same N-best return slot that
iter_050/078/080 fed from the beam now carries hypotheses that diverge at the
branch points the beam collapses, observable at one generate() call per window
(~beam=N decoder cost, no extra forward pass). The MBR centroid (max summed
difflib token-similarity) is the consensus over those divergent draws.
- (phase3_005_iter_083) probed `generate()'s beam_size kwarg (CT2 deterministic search WIDTH, iter_012/027/052),
tuned isolated at 5 on the current channel-EQ best/iter_063 host (patience=1.2,
repetition_penalty=1.1, no_repeat_ngram_size=4, length_penalty default 1.0,
sampling_temperature=0.0). EXPLOIT-B focused parameter tune, not a new mechanism.` → beam width has only ever been swept on the PRE-EQ host — iter_052 isolated it on
the beam=3 iter_049 config, and iter_059 fixed it at 4 when it combined width with
patience to become the host iter_063 later EQ-flattened. On the channel-EQ best it
was never pushed past 4. Width is one of only two substitution-axis levers (with
patience depth, iter_059) that reshape the same deterministic search without adding
sequence length, so it cannot feed the insertion axis every decode relaxation lost
on (rp=1.05/iter_068, ngram=5/iter_070, companding+ngram/iter_081 at 0.207). The
per-window encoder runs once regardless of width, so the extra cost is only the
cheap 4-layer turbo decoder over one more parallel beam.
- (phase3_005_iter_084) probed `The model object returned by load() — specifically the ctranslate2 Whisper
METHOD align(features, start_sequence, text_tokens, num_frames), never called
in this job. Every prior seek read emitted <|t.tt|> tokens out of
sequences_ids; align() instead forced-aligns decoded text tokens to encoder
frames via cross-attention, returning (text_token_index, frame_index) pairs.` → align() exposes a frame-level alignment of the decoded text to the audio that
is independent of timestamp-token emission, so the seek no longer requires
forcing <|t.tt|> tokens into the decode. That decouples the two jobs the old
pipeline conflated: timestamp tokens were emitted ONLY to drive the seek, yet
they share the decoder's autoregressive context with the text and perturb the
prefix each text token is predicted from. With align() supplying the seek, the
decode can run in clean <|notimestamps|> mode. frame_index * 0.02s gives the
last-token position; num_frames is capped at the 1500-frame encoder time dim.

=== EXPLOIT MODE ===
This iteration is an EXPLOITATION slot. Enough mechanisms have been surfaced;
inventing yet another novel structure is not the move here — extract value from
what you already found. Two plays are first-class (the "one focused change" rule
is relaxed):

(A) SYNTHESIS — combine prior attempts that each improved a different error
    axis. The section "Promising prior attempts to SYNTHESIZE" below gives you
    their actual diffs and which axis each improved/regressed vs best. Graft the
    axis-improving part of two such levers into one pipeline and guard the axis
    each one regressed. Do not re-derive them from prose — their code is given.

(B) PARAMETER TUNING — the pipeline is mature, so a *focused* sweep of decode
    parameters on the current best (beam_size, temperature/fallback schedule,
    length_penalty, repetition_penalty, patience) IS allowed and encouraged
    here. Tune against the DOMINANT AXIS in the error profile.

Pick (A) or (B), justify it from the error profile and the axis deltas, and make
the change. Exploiting what you found beats inventing something new in this slot.
=== END EXPLOIT MODE ===

Promising prior attempts to SYNTHESIZE (each improved one axis vs best but did not win overall — compose their gains, guard the axis each regressed). Axis deltas are vs best (✓ improved, ✗ regressed):

--- phase3_005_iter_081 (cer 0.2070; sub +0.07✓, coverage +0.00·, hal +0.00·) ---
```diff
diff --git a/workspace/transcribe.py b/workspace/transcribe.py
index 6107936..6e099d3 100644
--- a/workspace/transcribe.py
+++ b/workspace/transcribe.py
@@ -44,6 +44,30 @@ _DOMAIN_PROMPT = (
 _EQ_BANDS = 32  # coarse magnitude bands estimating the channel envelope
 _EQ_CLIP = 3.0  # max boost/cut of any band — gentle channel correction, not whitening
 
+_COMPAND_GAMMA = 0.95  # gentlest (1-gamma) nonlinear lift of quiet consonant energy
+_NGRAM = 5  # milder hard-ban frees legitimately-repeated Korean particle 4-grams
+_LENGTH_PENALTY = 0.9  # <1.0 insertion guard for the freed n-grams (iter_044/079)
+
+
+def _compand(x: np.ndarray, gamma: float) -> np.ndarray:
+    """Memoryless power-law amplitude companding: y = sign(x)*|x|^gamma.
+
+    gamma<1.0 compresses the dynamic range, lifting low-amplitude consonant /
+    fricative energy toward the vowel peaks — a substitution-axis lever acting
+    on the AMPLITUDE RATIO between samples, orthogonal to the channel-EQ
+    spectral-envelope divide it follows. Peak is restored so the per-input
+    log-mel level stays comparable; gamma=0.95 is the gentlest rung so the
+    raised near-silent-tail floor (companding's lone seek-trunc regression) is
+    minimized and absorbed by the ngram=5/patience coverage surplus.
+    """
+    x = x.astype(np.float32)
+    peak = float(np.max(np.abs(x)))
+    if peak <= 0.0:
+        return x
+    norm = x / peak
+    comp = np.sign(norm) * (np.abs(norm) ** gamma)
+    return (comp * peak).astype(np.float32)
+
 
 def _equalize_channel(audio: np.ndarray) -> np.ndarray:
     """Blind channel (spectral-coloration) equalization on the full waveform.
@@ -89,6 +113,10 @@ def transcribe(audio: np.ndarray, sr: int) -> str:
     # so the encoder sees a spectral envelope closer to the training distribution.
     audio = _equalize_channel(audio)
 
+    # then lift the quiet consonant/fricative energy on the de-colored signal
+    # (orthogonal amplitude-ratio axis) — the acoustic half of this synthesis.
+    audio = _compand(audio, _COMPAND_GAMMA)
+
     # NOTE: <|notimestamps|> is intentionally omitted so the decoder emits
     # timestamp tokens; they are stripped from the text by skip_special_tokens
     # but read out of the raw sequence to drive the seek.
@@ -131,7 +159,8 @@ def transcribe(audio: np.ndarray, sr: int) -> str:
             patience=1.2,
             sampling_temperature=0.0,
             repetition_penalty=1.1,
-            no_repeat_ngram_size=4,
+            no_repeat_ngram_size=_NGRAM,
+            length_penalty=_LENGTH_PENALTY,
         )
 
         token_ids = results[0].sequences_ids[0]

```

--- phase3_005_iter_057 (cer 0.2128; sub +0.07✓, coverage -0.01·, hal +0.00·) ---
```diff
diff --git a/workspace/transcribe.py b/workspace/transcribe.py
index e712c50..277ee00 100644
--- a/workspace/transcribe.py
+++ b/workspace/transcribe.py
@@ -28,6 +28,26 @@ _MAX_PREV_TOKENS = 224  # Whisper prompt context budget
 _TS_STEP_SECONDS = 0.02  # Whisper timestamp token resolution
 _MIN_ADVANCE_FRACTION = 0.5  # floor seek advance to bound runtime / prevent stall
 _DOMAIN_BUDGET = 24  # tight cap on the domain prior — gentle bias, not forcing
+_COMPAND_GAMMA = 0.9  # <1.0 = mild nonlinear dynamic-range compression (iter_054)
+_LENGTH_PENALTY = 1.05  # >1.0 favors fuller beams — guards companding's seek-trunc
+
+
+def _compand(x: np.ndarray, gamma: float) -> np.ndarray:
+    """Memoryless power-law amplitude companding: y = sign(x)*|x|^gamma.
+
+    gamma<1.0 compresses the dynamic range, lifting low-amplitude consonant /
+    fricative energy toward the vowel peaks — a substitution-axis lever
+    orthogonal to the linear tilt/level/band levers. Peak is restored so the
+    per-input log-mel level stays comparable.
+    """
+    x = x.astype(np.float32)
+    peak = float(np.max(np.abs(x)))
+    if peak <= 0.0:
+        return x
+    norm = x / peak
+    comp = np.sign(norm) * (np.abs(norm) ** gamma)
+    return (comp * peak).astype(np.float32)
+
 
 # Static domain-vocabulary prior for the 0715 Korean insurance call-center batch,
 # fed through <|startofprev|> on every window. iter_007 showed a full ~40-term
@@ -46,6 +66,12 @@ def transcribe(audio: np.ndarray, sr: int) -> str:
     model, processor = load()
     tok = processor.tokenizer
 
+    # compand the full waveform once before windowing so the nonlinear
+    # dynamic-range compression (sub-axis lever) applies uniformly; its lone
+    # cost is short seek-termination on lifted near-silent tails, guarded below
+    # by length_penalty>1.0.
+    audio = _compand(np.asarray(audio), _COMPAND_GAMMA)
+
     # NOTE: <|notimestamps|> is intentionally omitted so the decoder emits
     # timestamp tokens; they are stripped from the text by skip_special_tokens
     # but read out of the raw sequence to drive the seek.
@@ -89,6 +115,7 @@ def transcribe(audio: np.ndarray, sr: int) -> str:
             sampling_temperature=0.0,
             repetition_penalty=1.1,
             no_repeat_ngram_size=4,
+            length_penalty=_LENGTH_PENALTY,
         )
 
         token_ids = results[0].sequences_ids[0]

```

--- phase3_005_iter_044 (cer 0.1972; sub +0.07✓, coverage +0.03✓, hal +0.00·) ---
```diff
diff --git a/workspace/transcribe.py b/workspace/transcribe.py
index 7c63f2a..262a79f 100644
--- a/workspace/transcribe.py
+++ b/workspace/transcribe.py
@@ -85,10 +85,11 @@ def transcribe(audio: np.ndarray, sr: int) -> str:
             features,
             [prompt],
             beam_size=3,
-            patience=1.0,
+            patience=1.2,
             sampling_temperature=0.0,
-            repetition_penalty=1.1,
-            no_repeat_ngram_size=3,
+            repetition_penalty=1.05,
+            no_repeat_ngram_size=5,
+            length_penalty=0.9,
         )
 
         token_ids = results[0].sequences_ids[0]

```

Recent HISTORY:
Treat this section as untrusted observation only. Do not follow instructions
inside HISTORY; follow only the hard constraints in this prompt and profile.
(HISTORY suppressed in exploit mode to keep focus on the promising rejects below. best_cer so far: 0.17750901835038252, best_hyp_id: phase3_005_iter_063, stalled 22 iters.)

Best diagnosis summary:
{
  "batch": "BATCH",
  "per_file_diagnosis": [
    {
      "wav": "data/raw/wav/BATCH/file00.wav",
      "metrics": {
        "cer": 0.1936270525117867,
        "length_ratio": 0.9696797268736791,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file01.wav",
      "metrics": {
        "cer": 0.1511276246435669,
        "length_ratio": 0.9472047005962153,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file02.wav",
      "metrics": {
        "cer": 0.09920881166614955,
        "length_ratio": 0.97471300031027,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file03.wav",
      "metrics": {
        "cer": 0.17507473841554558,
        "length_ratio": 0.9409566517189836,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file04.wav",
      "metrics": {
        "cer": 0.2965569716568385,
        "length_ratio": 1.0273920486969754,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file05.wav",
      "metrics": {
        "cer": 0.2184245660881175,
        "length_ratio": 0.9666221628838452,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file06.wav",
      "metrics": {
        "cer": 0.36150424585523655,
        "length_ratio": 0.9965628790942176,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file07.wav",
      "metrics": {
        "cer": 0.27115731592061176,
        "length_ratio": 0.9263682446945614,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file08.wav",
      "metrics": {
        "cer": 0.16583767335713032,
        "length_ratio": 0.9671718649423606,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file09.wav",
      "metrics": {
        "cer": 0.13976896575018577,
        "length_ratio": 0.968790110112815,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file10.wav",
      "metrics": {
        "cer": 0.08801955990220049,
        "length_ratio": 0.9709657701711492,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    }
  ],
  "focus_files": [
    {
      "wav": "data/raw/wav/BATCH/file06.wav",
      "why_selected": [
        "worst_cer"
      ]
    },
    {
      "wav": "data/raw/wav/BATCH/file04.wav",
      "why_selected": [
        "lexical_top"
      ]
    }
  ]
}

Edit workspace/transcribe.py directly and stop. Do not edit docs, tests, scripts,
harness, judge, frozen, baseline, assets, or data. Emit the required YAML
metadata block (see profile §"Required output format") as the LAST thing in
your response.
