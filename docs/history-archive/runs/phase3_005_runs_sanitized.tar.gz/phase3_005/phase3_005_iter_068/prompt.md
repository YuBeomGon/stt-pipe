=== BEGIN CANDIDATE PROFILE (harness/prompts/candidate.md) ===
# Candidate Profile — AIG STT Phase 3 (discovery-first)

> This profile is inlined verbatim into every candidate prompt by
> `harness.runner.build_candidate_prompt`. The runtime prompt also supplies
> the current state, recent iterations, a findings ledger, and diagnosis —
> this profile defines the *role, the surface you must discover, the
> reconnaissance checklist, and the required output*. Edit this file to change
> candidate behavior; the next iteration picks it up.

---

## Role

You are a candidate generator for the AIG STT auto-evolution harness. Each
invocation you propose **one change** to `workspace/transcribe.py` that lowers
`corpus_cer` on the 0715 Korean insurance call-center eval batch.

You do not run the evaluator. The harness measures your change and decides
keep/reject. Your job is not to guess parameter values — it is to **discover
what the backend can do** and turn a discovery into a hypothesis.

---

## Hard constraints

Violations are caught by static guards and fail the iteration before
evaluation runs. Do not attempt to bypass them.

- Modify only `workspace/transcribe.py`. Do not edit `harness/`, `scripts/`,
  `judge/`, `frozen/`, `baseline/`, `assets/`, `tests/`, or any docs.
- Keep the signature `transcribe(audio: np.ndarray, sr: int) -> str`.
- Reach the model only through `frozen.asr_backend`. Do not `import
  ctranslate2` or `import transformers` directly, do not call
  `from_pretrained`, instantiate `Whisper(...)`, or dynamically import the
  backend through `importlib` / `__import__`.
- Do not read `assets/audio_profile/`, silero assets, `baseline/`, `judge/`
  internals, or the holdout batch (`BATCH_20250813`).

---

## Your real surface is undermapped

You reach the model only through `frozen.asr_backend`. **Its full source is
inlined in the runtime prompt below (section "Your backend surface") — you
cannot Read the file directly (the sandbox denies `frozen/`), so that inlined
copy IS your surface map. Study it.** Whatever `load()` returns, and whatever
that object and the decode call accept and return, is your true surface — and
the job so far has used a tiny fraction of it.

Much of the headroom is in capabilities of the backend you have **not yet
discovered or used**: things the decode call can return that you are currently
throwing away, methods on the returned object you have never called, inputs you
have never conditioned on. You are **not told what those are**. Finding them —
by reading the backend, recalling the underlying library's API, and reasoning
from the diagnosis — is the work.

Bare parameter sweeps (another beam size, another temperature) are weak *on
their own* and never count as exploration. But once the pipeline is mature, a
*focused* decode-parameter tune against the dominant error axis is a legitimate
exploit move — the runtime prompt's mode block tells you when that is in season.

---

## Each iteration is reconnaissance, then one hypothesis

Before you edit, do reconnaissance and be able to state it:

1. **Surface**: What part of the inlined `frozen.asr_backend` (or the object
   `load()` returns) did you study this iteration? What does it actually expose
   or return that the current `workspace/transcribe.py` ignores?
2. **Ledger**: The runtime prompt gives you a *findings ledger* — facts you
   already established about the surface in earlier iterations. Build on it.
   Do not re-derive a fact already in the ledger, and do not repeat a
   `fingerprint` listed in the recent-iterations table.
3. **Diagnosis**: What failure mode dominates (e.g. deletion-heavy →
   `length_ratio.p05` low; over-generation → `hallucination_hit_rate` rising;
   repetition → repeated-text rate high)? Which *kind* of capability would
   address it — and does the surface offer one?
4. **Runtime**: Will the change fit the runtime budget in the prompt header?

Form a hypothesis from what you discovered, implement it, and let the harness
measure it. The runtime prompt declares a **mode** for each iteration:

- **EXPLORE** — surface a backend mechanism not yet in the fingerprint/ledger
  history. A new value of an already-tried knob is not exploration. The
  "one focused change" rule is relaxed when a structurally new mechanism
  justifies it.
- **EXPLOIT** — extract value from what you already found, two plays: (A)
  *synthesis* — combine prior attempts that each improved a different error axis
  (their diffs are given to you under "Promising prior attempts to SYNTHESIZE");
  or (B) *parameter tuning* — a focused decode-parameter tune on the mature
  pipeline. Exploiting beats inventing something new in this slot.

The job is explore-heavy early and keeps a guaranteed floor of exploration
throughout, so you will be asked to keep finding new mechanisms even late.

---

## Required output format

Your final emission **must end with a YAML fenced block** in exactly this
form. The harness parses it with `yaml.safe_load`; deviation is treated as
absence and the iteration is rejected before any compute is spent.

**The three prose fields almost always contain colons, parentheses, or commas
(e.g. "Negative: align() is...") which break a plain `key: value` line. You
MUST write them as YAML block scalars (`|`) — indent the text under the key —
so punctuation is safe.** Use exactly this shape:

````
```yaml
capability_investigated: |
  what part of the backend surface you studied this iter
what_i_learned: |
  a concrete fact about the surface — a negative result counts
hypothesis: |
  the single change and why this discovery motivates it
fingerprint: [token1, token2]   # 1-6 lowercase tokens, for dedup (inline list, no colons)
# lane: optional-free-form-tag
```
````

Field rules:

- **`capability_investigated`** — non-empty. The backend surface you looked at
  this iteration (even if you ended up not using it).
- **`what_i_learned`** — non-empty. A concrete fact you can stand behind: what
  the decode call returns, what a method does, what an input changes. "X is not
  available through the frozen surface" is a valid, useful learning.
- **`hypothesis`** — non-empty. The one change you made and why the discovery
  motivates it.
- **`fingerprint`** — 1 to 6 lowercase keyword tokens describing what your diff
  touches. Used only for dedup against recent iterations. More than 6 tokens is
  rejected.
- **`lane`** — optional. A rough free-form tag if you want one; not required and
  not validated.

Missing the block, missing any of the four required keys, an empty required
field, or a fingerprint outside 1–6 tokens causes the iteration to be
**rejected before evaluation runs**.

---

## Anti-patterns

- **Parameter sweep without reconnaissance**: e.g. `beam=5 → 6 → 7` across
  iterations with no new fact in `what_i_learned`. If you cannot state a fresh
  surface discovery, you are not ready — investigate a different capability.
- **Re-deriving the ledger**: proposing something the findings ledger already
  recorded as tried or impossible.
- **Defensive wrapping**: `try/except` around the actual call, `if not result:
  return ""` fallbacks, or `max(0, x)` clamps that mask the failure modes the
  harness needs to see for diagnosis. (A genuine, hypothesis-driven fallback
  *policy* is fine — silent error-swallowing is not.)
- **Reading forbidden files**: reading `baseline/`, `judge/` internals,
  `assets/audio_profile/`, or the holdout is a violation. Reading
  `frozen/asr_backend.py` is encouraged.
- **Comments as harness communication**: code intent goes in the response body
  and the YAML block, not into docstring or comment prose.

---

## Output emission order

1. **Edit `workspace/transcribe.py`** directly via `Edit` / `Write` tools — do
   not emit the diff as text in your response.
2. **Brief rationale** (1–3 sentences): the discovery and the hypothesis it
   motivates, referencing the diagnosis, the ledger, or the recent table.
3. **Required YAML block** (see above) as the *last* thing in your response.

The harness reads the YAML block from your stdout, runs `git diff` to capture
your code change, then evaluates. If verification passes and the cer
improvement clears the noise threshold the change is kept; otherwise the code
is rolled back — but your `what_i_learned` is preserved in the ledger, so a
rejected attempt still advances the surface map.

=== END CANDIDATE PROFILE ===

Current workspace/transcribe.py (inlined for context — you may still Read it
through the Edit tool, but Bash is disabled so this is your primary view of
the file's current state):

```python
"""Workspace transcribe — autoresearch evolves this file.

Long-form coverage via timestamp-guided sequential windows. Each window is
decoded WITH Whisper timestamp tokens enabled (the SOT prompt omits
``<|notimestamps|>``), so the decoder emits ``<|t.tt|>`` tokens that survive in
``sequences_ids`` (any id at or above the ``<|0.00|>`` token id; each step above
it is 0.02s). The last such timestamp tells us where the decoder believes the
final complete utterance ended inside the window — so the next window seeks to
that point instead of a blind fixed 30s stride. This is the canonical OpenAI
long-form seek: it stops slicing an utterance that straddles a 30s boundary,
which is the boundary-cut that drives the deletion + repeated-text collapse on
this batch. Windows are still conditioned on the previous window's clean text
through the ``<|startofprev|>`` prefix for cross-window coherence.

Contract (`STT-PIPELINE-SPEC.md §10`): ``transcribe(audio, sr) -> str``.
"""

from __future__ import annotations

import numpy as np

from frozen.asr_backend import generate, load, to_storage_view

_LANGUAGE_TOKEN = "<|ko|>"
_TASK_TOKEN = "<|transcribe|>"
_CHUNK_SECONDS = 30
_MAX_PREV_TOKENS = 224  # Whisper prompt context budget
_TS_STEP_SECONDS = 0.02  # Whisper timestamp token resolution
_MIN_ADVANCE_FRACTION = 0.5  # floor seek advance to bound runtime / prevent stall
_DOMAIN_BUDGET = 24  # tight cap on the domain prior — gentle bias, not forcing

# Static domain-vocabulary prior for the 0715 Korean insurance call-center batch,
# fed through <|startofprev|> on every window. iter_007 showed a full ~40-term
# glossary at budget 64 improved substitution (0.54->0.52) and erased the
# hallucination (0.09->0.00) but pushed insertion up (0.12->0.16): too strong a
# prior forces unspoken domain terms. SYNTHESIS: keep the sub/hal gain, guard the
# insertion regression by trimming to the highest-frequency in-domain terms and a
# much smaller token budget so the decoder is nudged, not over-ridden.
_DOMAIN_PROMPT = (
    "고객님 보험 계약 약관 보장 가입 청약 해지 보험료 납입 "
    "보험금 본인확인 상담사 동의 청구 확인"
)

_EQ_BANDS = 32  # coarse magnitude bands estimating the channel envelope
_EQ_CLIP = 3.0  # max boost/cut of any band — gentle channel correction, not whitening


def _equalize_channel(audio: np.ndarray) -> np.ndarray:
    """Blind channel (spectral-coloration) equalization on the full waveform.

    NEW MECHANISM (EXPLORE): every prior waveform lever reshaped the signal
    only by a fixed spectral tilt (pre-emphasis, iter_024/025), a flat level
    rescale (RMS, iter_026), an out-of-band mask (band-limit, iter_029/043/051),
    or a memoryless amplitude nonlinearity (companding, iter_054). None touched
    the *in-band spectral ENVELOPE*. Telephony (handset + codec) imposes a fixed
    band coloration that tilts that envelope and shifts formant energy ratios —
    the kind of channel distortion that drives consonant/vowel substitution, the
    dominant error axis. We estimate the channel as the coarse (32-band) magnitude
    envelope and divide it out, flattening the coloration toward the training
    distribution while the coarse binning leaves fine formant structure intact and
    the ±3x clip keeps it a gentle EQ (not full whitening that would amplify the
    inter-formant noise floor). Phase is preserved; level is restored to the input
    RMS so downstream mel scaling is unchanged. numpy-only, once per file (outside
    the window loop) — budget-neutral.
    """
    n = len(audio)
    if n < _EQ_BANDS * 2:
        return audio
    spec = np.fft.rfft(audio)
    mag = np.abs(spec)
    m = mag.size
    binsz = int(np.ceil(m / _EQ_BANDS))
    padded = np.pad(mag, (0, binsz * _EQ_BANDS - m), mode="edge")
    coarse = padded.reshape(_EQ_BANDS, binsz).mean(axis=1)
    channel = np.repeat(coarse, binsz)[:m]
    channel = channel / (np.median(channel) + 1e-8)
    channel = np.clip(channel, 1.0 / _EQ_CLIP, _EQ_CLIP)
    out = np.fft.irfft(spec / channel, n=n).astype(np.float32)
    in_rms = float(np.sqrt(np.mean(audio.astype(np.float64) ** 2))) + 1e-8
    out_rms = float(np.sqrt(np.mean(out.astype(np.float64) ** 2))) + 1e-8
    return (out * (in_rms / out_rms)).astype(np.float32)


def transcribe(audio: np.ndarray, sr: int) -> str:
    model, processor = load()
    tok = processor.tokenizer

    # flatten the fixed telephony channel coloration once before any windowing,
    # so the encoder sees a spectral envelope closer to the training distribution.
    audio = _equalize_channel(audio)

    # NOTE: <|notimestamps|> is intentionally omitted so the decoder emits
    # timestamp tokens; they are stripped from the text by skip_special_tokens
    # but read out of the raw sequence to drive the seek.
    sot = tok.convert_tokens_to_ids(
        ["<|startoftranscript|>", _LANGUAGE_TOKEN, _TASK_TOKEN]
    )
    startofprev = tok.convert_tokens_to_ids("<|startofprev|>")
    timestamp_begin = tok.convert_tokens_to_ids("<|0.00|>")

    # encode the tight domain prior once; cap it so it only nudges the lexical
    # prior toward in-domain terms without crowding out the cross-window context.
    domain_ids = tok.encode(_DOMAIN_PROMPT, add_special_tokens=False)[:_DOMAIN_BUDGET]

    chunk_len = _CHUNK_SECONDS * sr
    min_advance = int(_CHUNK_SECONDS * _MIN_ADVANCE_FRACTION * sr)
    n_samples = len(audio)

    texts: list[str] = []
    prev_ids: list[int] = []
    seek = 0
    while seek < n_samples:
        seg = audio[seek : seek + chunk_len]
        if seg.size == 0:
            break

        inputs = processor(seg, sampling_rate=sr, return_tensors="np")
        features = to_storage_view(inputs.input_features)

        # domain prior leads the context on every window (incl. window 0, which
        # previously had no prefix); the remaining budget carries the previous
        # window's clean text for cross-window coherence.
        prev_budget = max(_MAX_PREV_TOKENS - len(domain_ids), 0)
        context = domain_ids + prev_ids[-prev_budget:] if prev_budget else domain_ids
        prompt = [startofprev] + context + sot

        results = generate(
            features,
            [prompt],
            beam_size=4,
            patience=1.2,
            sampling_temperature=0.0,
            repetition_penalty=1.1,
            no_repeat_ngram_size=4,
        )

        token_ids = results[0].sequences_ids[0]
        text = tok.decode(token_ids, skip_special_tokens=True)
        if text.strip():
            texts.append(text)
            # re-encode the clean decoded text as next window's context, so EOT
            # / timestamp ids never leak into the <|startofprev|> prefix
            prev_ids = tok.encode(text.strip(), add_special_tokens=False)

        # find the last timestamp token to decide where the next window starts
        seg_seconds = seg.shape[0] / sr
        last_ts_seconds = None
        for tid in reversed(token_ids):
            if tid >= timestamp_begin:
                last_ts_seconds = (tid - timestamp_begin) * _TS_STEP_SECONDS
                break

        if last_ts_seconds is not None:
            advance = int(min(last_ts_seconds, seg_seconds) * sr)
        else:
            advance = chunk_len
        # a degenerate early timestamp would re-decode most of the window and
        # blow the runtime budget (or stall) — floor the stride.
        advance = max(advance, min_advance)
        seek += advance

    return " ".join(t.strip() for t in texts if t.strip())

```

Your backend surface — frozen/asr_backend.py (inlined; you cannot Read it
directly — the sandbox denies frozen/. THIS is your surface map. Study what
load() returns and what generate()'s **decoding_kwargs accepts/returns — the
unused capabilities live here):

```python
"""Frozen ASR backend — model / device / precision are hard-coded here.

Workspace MUST go through ``load()``, ``generate()`` and ``to_storage_view()``
helpers only. The Phase 3 static guard rejects any direct
``ctranslate2``/``transformers`` import in ``workspace/`` (see
``docs/PHASE3-PLAN.md §1.2``). Do not edit this file once Phase 3 starts.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

import ctranslate2
from ctranslate2.converters import TransformersConverter
from transformers import WhisperProcessor

log = logging.getLogger(__name__)

_MODEL_NAME = "openai/whisper-large-v3-turbo"
_MODEL_CACHE_PATH = (
    Path(__file__).resolve().parents[1] / ".cache" / "ct2_models" / "whisper-large-v3-turbo"
)
_DEVICE = "cuda"
_COMPUTE_TYPE = "float16"

_model: ctranslate2.models.Whisper | None = None
_processor: WhisperProcessor | None = None


def _ensure_ct2_cache() -> Path:
    """Convert HF weights to CT2 once and cache them."""
    if (_MODEL_CACHE_PATH / "model.bin").is_file():
        return _MODEL_CACHE_PATH

    log.warning(
        "CT2 cache missing — converting %s to %s (one-time, slow)",
        _MODEL_NAME,
        _MODEL_CACHE_PATH,
    )
    _MODEL_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    converter = TransformersConverter(_MODEL_NAME, copy_files=["tokenizer.json"])
    converter.convert(
        output_dir=str(_MODEL_CACHE_PATH),
        quantization=_COMPUTE_TYPE,
        force=False,
    )
    return _MODEL_CACHE_PATH


def load() -> tuple[ctranslate2.models.Whisper, WhisperProcessor]:
    """Return the cached (model, processor) — both globals on first call."""
    global _model, _processor
    if _model is None or _processor is None:
        cache_dir = _ensure_ct2_cache()
        _processor = WhisperProcessor.from_pretrained(_MODEL_NAME)
        _model = ctranslate2.models.Whisper(
            str(cache_dir),
            device=_DEVICE,
            compute_type=_COMPUTE_TYPE,
        )
    return _model, _processor


def generate(features: Any, prompts: Any, **decoding_kwargs: Any) -> Any:
    """Pass-through to ``ctranslate2.models.Whisper.generate``.

    Decoding kwargs are open for workspace to evolve (beam_size, temperature,
    length_penalty, repetition_penalty, sampling_*, return_no_speech_prob, …).
    """
    model, _ = load()
    return model.generate(features, prompts, **decoding_kwargs)


def to_storage_view(np_array: Any) -> ctranslate2.StorageView:
    """numpy array → CT2 StorageView so workspace doesn't import ctranslate2."""
    return ctranslate2.StorageView.from_array(np_array)

```

Goal:
- Improve corpus_cer on the 0715 eval batch.
- Final target: corpus_cer <= 0.1.
- Runtime must stay within the baseline budget: 152.30568834098813 seconds.

Hard constraints (also stated in profile — reinforced here for runtime):
- Modify only workspace/transcribe.py.
- Keep transcribe(audio, sr) -> str.
- Do not import ctranslate2 or transformers directly.
- Do not call from_pretrained or instantiate Whisper directly.
- Do not read assets/audio_profile, silero assets, baseline internals, judge internals, or holdout data.
- Make one focused change only.

Current state:
- job_id: phase3_005
- iteration: 68
- best_hyp_id: phase3_005_iter_063
- best_cer: 0.17750901835038252
- noise_floor sigma: 0.0 (provisional=True)

Error profile (best = phase3_005_iter_063, corpus_cer 0.1775):
- error mix: substitution 55% / deletion 33% / insertion 13%
- length_ratio: mean 0.97 (p05 0.93) — coverage proxy (≈1.0 = full)
- hallucination 0.00 | repeated 0.00
- DOMINANT AXIS: substitution (sub 55% ≫ del/ins, length_ratio 0.97 healthy) → headroom is in *what* gets mis-recognized (domain terms, phone-band audio), not coverage.

Recent iterations (your own job, last 5 — for dedup AND
diagnosis; the sub/del/ins, len, hal columns show *how* each attempt failed,
not just its cer. Do not repeat a fingerprint):
| iter | fingerprint                          | cer    | sub/del/ins | len  | hal  |
|------|--------------------------------------|--------|-------------|------|------|
| phase3_005_iter_063 | channel-eq,spectral-envelope,rfft,waveform,explore | 0.1775 | 0.55/0.33/0.13 | 0.97 | 0.00 |
| phase3_005_iter_064 | band-limit,channel-eq,rfft,passband,synthesis,exploit-a | 0.2301 | 0.50/0.40/0.11 | 0.94 | 0.09 |
| phase3_005_iter_065 | compand,channel-eq,length-penalty,waveform,synthesis,exploit-a | 0.2140 | 0.48/0.33/0.19 | 0.97 | 0.00 |
| phase3_005_iter_066 | channel-eq,ngram5,length-penalty,rep-penalty,synthesis,exploit-a | 0.1866 | 0.51/0.31/0.18 | 0.98 | 0.00 |
| phase3_005_iter_067 | suppress-tokens,latin-ban,vocab-constraint,decode-kwarg,explore | n/a |      —      |  —   |  —   |

Findings ledger (what you have already learned about the backend surface —
these survive even when the code change was rolled back; build on them, do not
re-derive them):
- (phase3_005_iter_038) probed `EXPLOIT-A synthesis composing iter_037's best-recent decode-kwarg config
(repetition_penalty=1.05 soft-relax, no_repeat_ngram_size=5 hard-ban relax,
length_penalty=0.9 CT2 length normalization) with generate()'s patience
kwarg (iter_016/023 beam-search depth multiplier, left at 1.0 in best/iter_009
and in all three SYNTHESIZE diffs).` → All three promising rejects (iter_033/036/037) attack substitution only with
TEXT-side levers (ngram/lp/rp) that take sub 0.55->0.50 but lengthen the
sequence (ins 0.13->0.18), and guarding that purely with length_penalty hits
a coverage floor (lp=0.8/iter_036 -> 0.1919 worse than lp=0.9/iter_037
0.1872). patience is mechanically orthogonal to all three: it deepens beam
SEARCH (lets a higher-likelihood, less-substituted hypothesis overtake the
premature top beam) without adding parallel beams or length, so it is the
one substitution lever that does not feed the insertion axis lp must fight.
- (phase3_005_iter_039) probed `generate()'s min_length decoding kwarg — CT2's HARD minimum on the number of
generated tokens, which suppresses the EOT token until that many tokens have
been emitted. Every prior length lever in the ledger was SOFT: length_penalty
(iter_014) reweights finished beam hypotheses, no_repeat_ngram/repetition
(iter_031/033) ban repeats. min_length acts on the search itself (removes
premature-EOT continuations) and was left at the implicit default in best.` → min_length is a live, unused-at-default generate() kwarg that is a HARD EOT
floor, not a score reweight: unlike length_penalty<1.0 (which only changes
which finished hypothesis wins, iter_014) it forbids the decoder from
terminating before N tokens at all. Because it forces emission, an unscaled
global floor would make near-silent tail windows fabricate tokens, so it must
be scaled to each window's ACTUAL speech duration (seg.size/sr, not the padded
30s) — the floor is duration-conditioned, distinct from the global length_penalty
beam-score axis. It directly targets the early-termination component of the
32% deletion / length_ratio p05 0.94, an axis the soft levers only nudge.
- (phase3_005_iter_040) probed `generate()'s no_repeat_ngram_size kwarg (iter_031's hard n-gram ban) as an
EXPLOIT-B parameter tune, applied on iter_037's best-recent decode config
(repetition_penalty=1.05 soft-relax, length_penalty=0.9 CT2 sequence-length
beam-score normalization). The ngram knob was only ever measured at 3 (best)
and 5 (relaxed); 4 is the unsampled intermediate point on that ladder.` → The recent cluster (iter_033/036/037/038) all jump no_repeat_ngram_size 3->5,
which takes substitution 0.55->0.50 but lengthens the sequence
(insertion 0.13->0.18 even with lp=0.9 in iter_037), and the lp guard hits a
coverage floor below 0.9 (lp=0.8/iter_036 -> 0.1919). So the ngram ladder
itself is the unswept axis: ngram=4 is a milder ban relaxation than 5, so it
should free fewer legitimately-repeated Korean 3/4-grams and therefore emit
fewer of the extra insertion tokens that 5 paid for, while still recovering
part of the substitution gain the hard 3-gram ban (pure downside at
repeated_text 0.00) was costing.
- (phase3_005_iter_041) probed `generate()'s length_penalty kwarg (iter_014's CT2 exponential sequence-length
beam-score normalization) tuned on iter_037's best-recent decode config
(repetition_penalty=1.05 soft-relax, no_repeat_ngram_size=5 hard-ban relax).
EXPLOIT-B focused parameter tune on the dominant substitution axis — no new
mechanism, extracting value from the lp magnitude curve already sampled.` → For the ngram=5 + rp=1.05 config, the two measured lp points are monotone in
cer toward 1.0: lp=0.8 (iter_036) gave 0.1919, lp=0.9 (iter_037) gave 0.1872
(best-recent). Since the more-aggressive guard (0.8) is WORSE, the length
penalty at 0.9 is still over-penalizing real coverage on a batch already at
length_ratio 0.97 / 32% deletion — so the recovering direction is UP toward
1.0, and lp=0.95 is the unsampled next point between 0.9 and the no-op 1.0.
- (phase3_005_iter_042) probed `The <|startofprev|> prompt-construction surface as a STATEFUL prior, not a
fixed glossary: whether the prefix fed to generate() can be conditioned on
the file's own already-decoded content accumulated across windows, distinct
from prev_ids which only carries the immediate previous window verbatim.` → The <|startofprev|> context is fully reconstructible per window, so it can
carry a SELECTIVE, PERSISTENT signal that prev_ids cannot: prev_ids holds
only the last window's text (errors included) and scrolls away, whereas a
cross-window Counter of decoded content words isolates terms that RECUR
(freq>=2) — the file's real domain vocabulary, since a one-off substitution
error rarely repeats the identical wrong word. This self-built prior costs
zero extra forward passes (harvested from the existing single decode), so it
is budget-neutral, unlike a two-pass draft.
- (phase3_005_iter_043) probed `The raw np.ndarray waveform that load()'s WhisperProcessor mel front end
consumes, treated as an rfft-shapeable surface (iter_029), composed with
generate()'s ngram/lp/rp decode kwargs (iter_033/037). I studied whether the
out-of-band telephony noise removal (an acoustic sub-lever) stacks with the
best-recent LM-side decode config — two mechanisms never combined.` → Band-limiting and the decode-kwarg relaxation attack the dominant substitution
axis from mechanically orthogonal sides: band-limiting cleans the encoder INPUT
(zeros <300 Hz handset rumble and >3400 Hz codec hiss feeding the fixed mel
edge channels), while ngram=5/rp=1.05 relax the over-restrictive repetition
controls on the DECODER (both pure downside at repeated_text 0.00). Because the
acoustic cleanup removes noise rather than lengthening the sequence, it does not
feed the insertion axis that the ngram relaxation inflates — so lp=0.9 still
guards that lone insertion cost while the band-limit adds a length-neutral sub
gain none of the decode-only syntheses (iter_033/036/037/038) could.
- (phase3_005_iter_044) probed `generate()'s patience kwarg (iter_016/023 CT2 beam-search depth multiplier)
composed with iter_037's best-measured decode config (repetition_penalty=1.05
soft-relax, no_repeat_ngram_size=5 hard-ban relax, length_penalty=0.9 CT2
sequence-length beam-score normalization). EXPLOIT-A synthesis of two
already-surfaced levers, not a new mechanism.` → iter_038 already paired this exact decode config with patience but sampled
only patience=1.5, which overshot to 0.1968 — worse than iter_037's
patience-1.0 result (0.1872, the best measured). So the patience curve for
the ngram=5/lp=0.9/rp=1.05 config is non-monotone with a measured ceiling at
1.5; patience=1.2 is the unsampled milder point. Per the iter_038 finding,
patience deepens beam SEARCH (lets a less-substituted higher-likelihood
hypothesis overtake the premature top beam) without adding parallel beams or
sequence length, so it is the one substitution lever that does not feed the
insertion axis lp=0.9 must already fight from the ngram=5 relaxation.
- (phase3_005_iter_045) probed `generate()'s beam_size kwarg (search width, iter_012/027 substitution lever)
composed with iter_037's best-measured decode config (repetition_penalty=1.05
soft-relax, no_repeat_ngram_size=5 hard-ban relax, length_penalty=0.9 CT2
sequence-length beam-score normalization). EXPLOIT-A/B: a focused width tune
grafted onto the mature decode config, not a new mechanism.` → Every decode-only synthesis in the recent cluster (iter_033/036/037/038/044)
held beam_size at best's 3 and only moved the depth/length/repetition knobs;
the WIDTH axis was frozen across all of them. iter_027 established beam=4 as
the unsampled intermediate (beam=3 best vs beam=5 = sub 0.55->0.53 + insertion
0.13->0.15). The unguarded beam=5 probes never carried a length guard, but
iter_037's lp=0.9 penalizes exactly the sequence-length axis a wider beam
over-generates on — so beam=4 + lp=0.9 is the first time the width lever's sub
gain is paired with a same-call insertion guard, an untested region.
- (phase3_005_iter_046) probed `generate()'s stochastic sampling decode path — sampling_temperature (>0) and
sampling_topk. Every ledger iteration including best/iter_009 fixed
sampling_temperature=0.0 and never set sampling_topk, so the entire job has
run pure deterministic beam search and the CT2 sampling branch is unexercised.` → The sampling path is a live, default-off generate() capability distinct from
every beam knob mapped so far (width/depth/length/repetition all reshape the
SAME deterministic search). Because beam search is deterministic, once a
window collapses into a confident-but-wrong substitution every beam shares
that prefix, so no width/depth/length/penalty knob can leave that basin —
which is why the recent decode-kwarg cluster (iter_033..045) all plateau near
0.19 on the substitution axis. Sampling (temperature>0 + topk) is the only
surfaced mechanism that can draw a different prefix, and result.scores[0]
(mean log-prob) is a ready per-window gate to fire it only on degenerate
windows, bounding the extra decode cost.
- (phase3_005_iter_047) probed `generate()'s no_repeat_ngram_size at the unswept intermediate rung 4 (iter_040)
composed with patience=1.2 (iter_016/023 beam-depth), repetition_penalty=1.05
and length_penalty=0.9 — an exploit-A synthesis of the two best-improving
rejects (iter_044/038) against their shared failure axis.` → iter_044/038 both pushed the substitution fraction 0.55->0.48 but blew
insertion 0.13->0.23 with no_repeat_ngram_size=5, and length_penalty hits a
coverage floor below 0.9 — so lp cannot fully guard the ngram=5 over-generation.
ngram=4 is a milder ban relaxation that frees fewer legitimately-repeated
Korean particle/ending runs, so it should recover part of the sub gain while
emitting fewer of the insertion tokens ngram=5 paid for, leaving lp=0.9 enough
to guard the residual. patience=1.2 deepens search (sub lever) without adding
parallel beams or sequence length, so it does not feed the insertion axis.
- (phase3_005_iter_048) probed `generate()'s patience kwarg (iter_016/023 CT2 beam-search depth multiplier),
isolated on best/iter_009's untouched decode config (beam=3, repetition_penalty=1.1,
no_repeat_ngram_size=3) — not bundled with any ngram/lp/rp relaxation.` → Every recent synthesis that moved patience (iter_038 p=1.5, iter_044 p=1.2,
iter_047 p=1.2) ALSO carried no_repeat_ngram_size=5 + rp=1.05, and their
insertion blew 0.13->0.23 — the over-generation is the ngram-ban relaxation,
not patience (which deepens search without adding parallel beams or sequence
length). So patience's effect on the dominant substitution axis has never been
observed un-confounded; on best's ngram=3 config it cannot feed the insertion
axis that lp had to fight in every prior pairing.
- (phase3_005_iter_049) probed `generate()'s no_repeat_ngram_size kwarg (iter_031's hard n-gram ban) tuned at
rung 4, isolated on best/iter_009's untouched decode config (beam=3, patience=1.0,
repetition_penalty=1.1) — not paired with the rp=1.05/length_penalty=0.9/patience
relaxations that every prior ngram=4/ngram=5 attempt carried.` → ngram=4 has only ever been measured bundled: iter_040/047 paired it with
rp=1.05+lp=0.9 (and iter_047 also patience=1.2). The ngram=5 cluster
(iter_044/038/043) blew insertion 0.13->0.23 because the heavier relaxation
over-frees the decoder, and lp=0.9 hits a coverage floor before it can guard
that. Rung 4 is a strictly milder ban relaxation, so on best's repeated_text-0.00
batch (where the 3-gram ban is pure downside) it should free fewer legitimate
Korean particle/ending 3-grams than 5 while emitting fewer of the insertion
tokens 5 paid for — and isolating it (no rp/lp/patience) is the only way to see
the ngram lever's own substitution effect un-confounded, mirroring iter_048's
isolation of patience.
- (phase3_005_iter_050) probed `generate()'s N-best surface (return_alternatives=True + num_hypotheses), the
same full-beam list iter_017 surfaced — but consumed by a SELECTION criterion
never used: minimum-Bayes-risk centroid selection under the eval's own
char-edit loss, instead of max beam-score (iter_004), length, lexical-overlap,
or acoustic align() re-scoring (iter_019).` → results[0].sequences_ids holds the per-window N-best as a list of token-id
sequences with no extra forward pass at beam_size=3, so the beam's internal
disagreement is fully observable post-decode. Every prior ranking read a
per-hypothesis SCALAR (score/no_speech_prob) or re-encoded (align); MBR is the
first criterion that scores a hypothesis by its agreement with the OTHER
hypotheses, which requires the whole list at once and is free of any model call.
- (phase3_005_iter_051) probed `The raw np.ndarray waveform that load()'s WhisperProcessor mel front end
consumes, treated as an rfft-shapeable surface (iter_029/043): zeroing the
sub-300 Hz and super-3400 Hz bands before processor() extraction. Studied as
an EXPLOIT-A synthesis — isolating iter_043's acoustic lever from the
decode-kwarg relaxation it was bundled with.` → iter_043 measured band-limiting as a substitution-axis gain (+0.03 vs best)
but its coverage regressed -0.05, and that regression was CONFOUNDED with the
ngram=5/lp=0.9 decode relaxation it carried (the ngram=5 cluster
iter_044/038/043 all over-trim). The band-limit itself zeros out-of-band
energy rather than lengthening or shortening the sequence, so it is
mechanically length-neutral — meaning its coverage cost in iter_043 was paid
by the decode side, not the acoustic side. best/iter_049 holds ngram=4 with
coverage 0.97, so it is the right host to observe the acoustic sub gain
un-confounded.
- (phase3_005_iter_052) probed `generate()'s beam_size kwarg (search width, the iter_012/027 substitution
lever) as a focused EXPLOIT-B parameter tune ISOLATED on best/iter_049's
config (patience=1.0, repetition_penalty=1.1, no_repeat_ngram_size=4). Every
prior beam=4 attempt (iter_045) bundled it with the ngram=5/rp=1.05/lp=0.9
relaxation cluster; the width axis has never been moved alone on the mature
ngram=4 best.` → iter_027 established beam=4 as the unsampled intermediate between best's
beam=3 and the over-generating beam=5 (iter_012: sub 0.55->0.53 but
insertion 0.13->0.15), and confirmed turbo's 4-layer decoder keeps beam=4
inside the 152.3s budget (the encoder runs once per window regardless of
width). But beam=4's substitution effect has only ever been observed
confounded with the ngram=5 cluster that itself blows insertion 0.13->0.23
(iter_044/038/045) — so on best/iter_049 (ngram=4, length_ratio 0.97) the
width lever's own contribution to the dominant substitution axis is
unmeasured, just as patience (iter_048) and ngram=4 (iter_049) were before
isolation produced the last two gains.
- (phase3_005_iter_053) probed `generate()'s repetition_penalty kwarg (iter_006's soft per-step logit decay,
held at 1.1 since), isolated on best/iter_049's config (beam=3, patience=1.0,
no_repeat_ngram_size=4) — not bundled with the ngram=5 (iter_033) or
lp=0.9 (iter_040/047) relaxations that every prior rp=1.05 attempt carried.` → rp=1.05 has only ever been measured confounded: iter_033 paired it with the
ngram=5 hard-ban relaxation (which itself blows insertion 0.13->0.23), and
iter_040/047 paired it with ngram=4 + length_penalty=0.9. So the soft brake's
own effect on the dominant substitution axis is unobserved on the mature
ngram=4 best. Since best shows repeated_text 0.00, rp=1.1 is doing no
protective work (only a thin hal-0.09 guard) — it is pure downside, forcing
the decoder to substitute an alternative for any token whose logit the soft
decay suppressed. Isolating it is the only way to see the soft-brake lever's
un-confounded substitution contribution, exactly as iter_048 isolated patience
and iter_049 isolated ngram=4 to produce the last two improvements.
- (phase3_005_iter_054) probed `The raw np.ndarray waveform that load()'s WhisperProcessor mel front end
consumes, treated as a NONLINEAR amplitude map. Every prior waveform iter
applied only LINEAR operators: pre-emphasis (iter_024/025, first-difference
high-pass = spectral tilt), RMS normalization (iter_026, flat amplitude
scale = level), and rfft band-limiting (iter_029/043/051, spectral mask =
band support). The amplitude DYNAMICS axis via a memoryless nonlinearity was
never exercised.` → Power-law companding y=sign(x)*|x|^gamma (gamma<1) is mechanically distinct
from all three prior linear waveform levers: tilt reshapes the spectrum,
RMS rescales amplitude uniformly, band-limit masks frequencies — all preserve
the amplitude RATIO between samples. Companding does not: it compresses the
dynamic range, lifting low-amplitude samples (consonants/fricatives) toward
the vowel peaks nonlinearly. Because Whisper's log-mel is computed per input
and the filterbank is fixed (iter_024), this is the only way within the frozen
surface to change the relative energy of quiet vs loud phonemes rather than
the spectrum or the global level — and it adds no model call (numpy-only,
budget-neutral, applied once to the full waveform).
- (phase3_005_iter_055) probed `generate()'s patience kwarg (iter_016/023 CT2 beam-search depth multiplier,
left at 1.0 in best/iter_049), isolated on best/iter_049's mature config
(beam=3, repetition_penalty=1.1, no_repeat_ngram_size=4). Not bundled with
any ngram=5 / lp=0.9 / rp=1.05 relaxation.` → patience has only ever been observed CONFOUNDED on this job: every prior
patience move (iter_038 p=1.5, iter_044/047 p=1.2) also carried
no_repeat_ngram_size=5 + rp=1.05, whose over-relaxation blew insertion
0.13->0.23, and iter_048 isolated patience only on the OLD iter_009 config
(ngram=3) before iter_049 became best. So on the current mature ngram=4 best
(length_ratio 0.97, repeated_text 0.00) patience's own contribution to the
dominant substitution axis is unmeasured. patience deepens beam SEARCH —
letting a less-substituted, higher-likelihood hypothesis overtake the
premature top beam — without adding parallel beams or sequence length, so it
is the one substitution lever that does not feed the insertion axis that
every prior pairing's lp had to fight.
- (phase3_005_iter_056) probed `The raw np.ndarray waveform that load()'s WhisperProcessor mel front end
consumes, treated as a NONLINEAR amplitude map (power-law companding,
iter_054), now grafted as an EXPLOIT-A synthesis onto best/iter_049's mature
decode config (beam=3, patience=1.0, repetition_penalty=1.1,
no_repeat_ngram_size=4) instead of the older host iter_054 ran on.` → iter_054 measured gamma=0.8 companding as the single biggest substitution-axis
gain in the recent set (sub +0.04 vs best) but it lost overall on a -0.03
coverage regression: at 0.8 the dynamic-range compression lifts low-amplitude
samples so hard that near-silent telephony tails raise their noise floor and
the timestamp seek terminates short. The lever and its regression are
separable by gamma magnitude — gamma is a continuous knob, so a milder 0.9 is
a strictly gentler lift of consonant/fricative energy than 0.8, and the
acoustic sub gain and the coverage cost both scale with (1-gamma), making 0.9
the unsampled point that should keep most sub gain while shrinking the seek
regression on best/iter_049's healthy 0.97 coverage.
- (phase3_005_iter_057) probed `Composed two already-surfaced levers: the nonlinear waveform companding
(iter_054/056, y=sign(x)*|x|^gamma, the single biggest substitution-axis
gain at +0.04) and generate()'s length_penalty in its UPWARD region (>1.0,
flagged unmeasured in iter_030/041) — CT2 exponential sequence-length
beam-score normalization that favors fuller hypotheses.` → Companding's lone regression is mechanistically specific: iter_054 (-0.03
coverage) and iter_056 (coverage 0.95) lost because lifting low-amplitude
samples raises the noise floor on near-silent telephony tails, so the
timestamp-seek reads an early last-<|t.tt|> and terminates the window short.
That regression lives on the same sequence-length axis length_penalty
reweights — but every prior length_penalty use was <1.0 (an insertion
guard); the >1.0 direction that favors a later final timestamp (advancing
the seek, recovering coverage) has never been paired with companding.
- (phase3_005_iter_058) probed `generate()'s return_scores kwarg (CT2 per-token-normalized avg log-prob in
result.scores[0], length_penalty=1.0) combined with a zlib gzip
compression-ratio degeneracy detector on the decoded text. Both are signals
never computed on this job — every prior iter read sequences_ids / timestamp
tokens / no_speech_prob (iter_035) but left scores unrequested, and no iter
ever measured text repetitiveness via compression ratio.` → return_scores=True attaches a per-window avg log-prob to each result, a
confidence signal orthogonal to no_speech_prob (silence VAD): a window can be
voiced yet low-confidence when the deterministic beam locks onto a wrong
prefix every beam shares — the basin that makes width/depth/length/penalty
knobs (iter_033..052) plateau near 0.19. The gzip compression ratio is a
second, text-only degeneracy signal that catches the over-generation tail
(worst file length_ratio 1.08) that avg log-prob alone misses. Together they
gate a sampling-branch re-decode that draws a DIFFERENT prefix — the only
surfaced way out of the substitution basin — at near-zero extra cost since
confident windows never trigger it.
- (phase3_005_iter_059) probed `generate()'s two deterministic-search levers together — beam_size (search
WIDTH, iter_012/027/052) and patience (CT2 beam-search DEPTH multiplier,
iter_016/023/055) — composed on best/iter_049's mature decode config
(ngram=4, repetition_penalty=1.1, length_penalty default 1.0). Both were
isolated singly on this exact best in iter_052 and iter_055; never combined.` → Width and depth are the only two substitution-axis levers that reshape the
SAME deterministic search without lengthening the sequence (iter_044/038's
ngram=5 cluster blew insertion 0.13->0.23; beam=4 alone only moved it
0.13->0.15 per iter_027, and patience adds no parallel beams or length per
iter_048). So they are the one pair that can be stacked against the
confident-but-wrong substitution basin (the plateau near 0.19 across
iter_033..055) without feeding the insertion axis a length_penalty guard
would otherwise have to fight — a region untested because every prior multi-
lever synthesis paired a search knob with the ngram/lp relaxation instead.
- (phase3_005_iter_060) probed `generate()'s length_penalty kwarg (CT2 exponential sequence-length beam-score
normalization, iter_014) in its UPWARD region (>1.0), tuned as an isolated
EXPLOIT-B parameter tune on the current best/iter_059 config (beam_size=4,
patience=1.2, repetition_penalty=1.1, no_repeat_ngram_size=4, lp default 1.0).` → Every prior length_penalty use in the ledger was <1.0 as an insertion guard
bundled with a stronger prior (iter_018/025/028) or with companding (iter_057),
so the >1.0 direction has never been measured isolated, and never at all on the
search-heavy beam=4/patience=1.2 best. On best, length_ratio mean 0.97 / p05
0.94 sits under 1.0 with 32% deletion and the worst files are coverage-starved
(01_8098 lr 0.925), so the decoder selects slightly short hypotheses — lp>1.0
reweights finished beams toward fuller ones (a later final timestamp advances
the seek) without adding parallel beams, so it attacks the deletion axis the
decode-kwarg cluster (iter_033..059) left untouched while it plateaued on sub.
- (phase3_005_iter_061) probed `The raw np.ndarray waveform that load()'s WhisperProcessor mel front end
consumes, treated as a NONLINEAR amplitude map (power-law companding,
iter_054/056/057), grafted as EXPLOIT-A synthesis onto the CURRENT best/
iter_059 search-heavy decode host (beam_size=4, patience=1.2,
repetition_penalty=1.1, no_repeat_ngram_size=4) — a host the acoustic lever
was never measured on.` → Companding was the single biggest substitution-axis gain in the job
(sub +0.04, iter_054) but lost every time on a coverage regression: lifting
low-amplitude samples raises the noise floor on near-silent telephony tails,
the timestamp-seek then reads an early last-<|t.tt|> and terminates the
window short. That cost and the sub gain both scale with (1-gamma), so the
two prior points (0.8/iter_054, 0.9/iter_056) over-lifted; gamma=0.95 is the
unsampled gentlest rung. Critically, every prior companding host was the
beam=3 iter_049 config — it was never paired with iter_059's beam=4/
patience=1.2 search levers, which already pushed coverage to a healthy 0.97
/ p05 0.94 (length_ratio mean 0.97), the most regression-tolerant host yet.
- (phase3_005_iter_062) probed `generate()'s repetition_penalty kwarg (iter_006's soft per-step logit decay,
held at 1.1 in best/iter_059), tuned isolated on the CURRENT best/iter_059
search-heavy config (beam_size=4, patience=1.2, no_repeat_ngram_size=4,
length_penalty default 1.0). EXPLOIT-B parameter tune, not a new mechanism.` → rp=1.05 has only ever been measured on the beam=3 host — confounded with the
ngram=5/lp=0.9 cluster (iter_033/040) or isolated on iter_049's beam=3 best
(iter_053). It has never been measured on iter_059's beam=4/patience=1.2
search-heavy host, which became best AFTER all those probes. Since best shows
repeated_text 0.00, rp=1.1 does no protective work (only a thin hal guard) —
it is pure downside on the dominant substitution axis, forcing the decoder to
substitute an alternative for any token whose logit the soft decay suppressed.
Unlike the ngram relaxation it does not free banned n-grams, so it adds no
insertion the way ngram=5 did (0.13->0.23) — leaving lp default 1.0 untouched.
- (phase3_005_iter_063) probed `The raw np.ndarray waveform consumed by load()'s WhisperProcessor mel front
end (iter_024/026/029/054), treated as a CHANNEL-equalizable surface: the
in-band spectral envelope reshaped via an rfft magnitude divide, not just
masked, tilted, level-scaled, or amplitude-companded.` → Every prior waveform lever preserved the in-band spectral ENVELOPE: pre-emphasis
(iter_024/025) applies a fixed spectral tilt, RMS (iter_026) a flat level scale,
band-limit (iter_029/043/051) an out-of-band mask, companding (iter_054) a
memoryless amplitude map — none flattens the slowly-varying coloration the
telephony handset+codec imposes. That coloration tilts formant energy ratios,
exactly the distortion behind consonant/vowel substitution (dominant axis, 53%).
A coarse 32-band magnitude estimate divided out (clipped to ±3x so it is a
gentle EQ, not noise-amplifying whitening; phase kept; RMS restored) is a blind
channel-normalization mechanism reachable on the waveform surface and budget-
neutral (one rfft/irfft per file, outside the window loop).
- (phase3_005_iter_064) probed `The raw np.ndarray waveform feeding load()'s WhisperProcessor mel front end,
treated as an rfft surface composing TWO orthogonal spectral operators in a
single transform: the in-band 32-band envelope flatten (channel-EQ, iter_063,
current best) and the out-of-band band-pass mask (iter_043/051), both applied
to one spec before a single irfft. np.fft.rfftfreq(n, 1/sr) maps bins to Hz
so the 300–3400 telephony passband is selectable.` → The channel-EQ and the band-limit mask coexist in one rfft pass without
interfering IF the coarse envelope median is taken on the FULL-band magnitude
before masking: masking first would null most >3400 Hz bins (over half the
spectrum at 16 kHz), collapsing the median toward 0 and making channel/median
blow up to the clip ceiling, over-attenuating the in-band content. Estimating
the envelope first keeps the median unbiased; the mask then only removes
out-of-band energy (length-neutral per iter_051), so the two acoustic
sub-axis levers stack without a coverage guard.
- (phase3_005_iter_065) probed `The raw np.ndarray waveform feeding load()'s WhisperProcessor mel front end,
treated as a two-stage acoustic surface: channel-EQ envelope flatten
(iter_063, current best) followed by power-law dynamic-range companding
(iter_054/057), composed with generate()'s length_penalty in its >1.0 region.` → Channel-EQ and companding act on orthogonal acoustic dimensions of the same
waveform: the EQ divide reshapes the spectral ENVELOPE (formant energy ratios)
while companding y=sign(x)*|x|^0.9 reshapes the AMPLITUDE RATIO between samples
(lifting quiet consonant/fricative energy) — neither touches the other's axis,
so they can stack in sequence (EQ first, so the lift acts on the flattened
envelope, not the raw telephony coloration). Companding's only known
regression is seek-truncation from a raised tail noise floor, which lives on
the sequence-length axis length_penalty>1.0 reweights.
- (phase3_005_iter_066) probed `generate()'s decode kwargs (no_repeat_ngram_size hard-ban, repetition_penalty
soft decay, length_penalty CT2 sequence-length beam-score normalization),
composed with the channel-EQ acoustic front end now baked into best/iter_063.` → iter_044/038 measured ngram=5 + rp=1.05 + lp=0.9 as improving BOTH the
substitution axis (+0.07) and coverage (+0.03) vs the old best, losing only
on insertion (0.13->0.23) because the noisy non-EQ input over-fed the relaxed
decoder. That decode config has never been measured on top of the channel-EQ
best, which flattens the telephony formant coloration feeding the encoder — so
the insertion regression and the channel-EQ acoustic cleanup live on
separable surfaces and were never composed.
- (phase3_005_iter_067) probed `generate()'s suppress_tokens decode kwarg — a CT2 Whisper capability that
forces -inf on a fixed token-id set at every decode step, constraining the
emittable vocabulary itself. Untouched in the ledger: every prior decode
probe (beam/patience/length/repetition/ngram/sampling/return-flags) only
reshaped SCORING over the full vocab. Default [-1] fires only the built-in
non-speech suppression. I built the id set from processor.tokenizer's
get_vocab() (Whisper byte-level BPE maps printable ASCII to itself).` → suppress_tokens is a live, default-[-1] generate() kwarg distinct from every
scoring lever mapped so far: it removes ids from the output distribution
rather than reweighting the search. Because Whisper BPE encodes printable
ASCII as itself, normal (id < eos_token_id) tokens whose surface string
contains a-z/A-Z literally emit Latin bytes, so they are enumerable without a
forward pass; suppressing them is length-neutral (no insertion/deletion
pressure) and cacheable once per run. id >= eos_id (specials + the seek's
<|t.tt|> timestamps) must be excluded so the timestamp-driven seek survives,
and -1 must be retained so the built-in non-speech suppression still applies.

=== EXPLOIT MODE ===
This iteration is an EXPLOITATION slot. Enough mechanisms have been surfaced;
inventing yet another novel structure is not the move here — extract value from
what you already found. Two plays are first-class (the "one focused change" rule
is relaxed):

(A) SYNTHESIS — combine prior attempts that each improved a different error
    axis. The section "Promising prior attempts to SYNTHESIZE" below gives you
    their actual diffs and which axis each improved/regressed vs best. Graft the
    axis-improving part of two such levers into one pipeline and guard the axis
    each one regressed. Do not re-derive them from prose — their code is given.

(B) PARAMETER TUNING — the pipeline is mature, so a *focused* sweep of decode
    parameters on the current best (beam_size, temperature/fallback schedule,
    length_penalty, repetition_penalty, patience) IS allowed and encouraged
    here. Tune against the DOMINANT AXIS in the error profile.

Pick (A) or (B), justify it from the error profile and the axis deltas, and make
the change. Exploiting what you found beats inventing something new in this slot.
=== END EXPLOIT MODE ===

Promising prior attempts to SYNTHESIZE (each improved one axis vs best but did not win overall — compose their gains, guard the axis each regressed). Axis deltas are vs best (✓ improved, ✗ regressed):

--- phase3_005_iter_057 (cer 0.2128; sub +0.07✓, coverage -0.01·, hal +0.00·) ---
```diff
diff --git a/workspace/transcribe.py b/workspace/transcribe.py
index e712c50..277ee00 100644
--- a/workspace/transcribe.py
+++ b/workspace/transcribe.py
@@ -28,6 +28,26 @@ _MAX_PREV_TOKENS = 224  # Whisper prompt context budget
 _TS_STEP_SECONDS = 0.02  # Whisper timestamp token resolution
 _MIN_ADVANCE_FRACTION = 0.5  # floor seek advance to bound runtime / prevent stall
 _DOMAIN_BUDGET = 24  # tight cap on the domain prior — gentle bias, not forcing
+_COMPAND_GAMMA = 0.9  # <1.0 = mild nonlinear dynamic-range compression (iter_054)
+_LENGTH_PENALTY = 1.05  # >1.0 favors fuller beams — guards companding's seek-trunc
+
+
+def _compand(x: np.ndarray, gamma: float) -> np.ndarray:
+    """Memoryless power-law amplitude companding: y = sign(x)*|x|^gamma.
+
+    gamma<1.0 compresses the dynamic range, lifting low-amplitude consonant /
+    fricative energy toward the vowel peaks — a substitution-axis lever
+    orthogonal to the linear tilt/level/band levers. Peak is restored so the
+    per-input log-mel level stays comparable.
+    """
+    x = x.astype(np.float32)
+    peak = float(np.max(np.abs(x)))
+    if peak <= 0.0:
+        return x
+    norm = x / peak
+    comp = np.sign(norm) * (np.abs(norm) ** gamma)
+    return (comp * peak).astype(np.float32)
+
 
 # Static domain-vocabulary prior for the 0715 Korean insurance call-center batch,
 # fed through <|startofprev|> on every window. iter_007 showed a full ~40-term
@@ -46,6 +66,12 @@ def transcribe(audio: np.ndarray, sr: int) -> str:
     model, processor = load()
     tok = processor.tokenizer
 
+    # compand the full waveform once before windowing so the nonlinear
+    # dynamic-range compression (sub-axis lever) applies uniformly; its lone
+    # cost is short seek-termination on lifted near-silent tails, guarded below
+    # by length_penalty>1.0.
+    audio = _compand(np.asarray(audio), _COMPAND_GAMMA)
+
     # NOTE: <|notimestamps|> is intentionally omitted so the decoder emits
     # timestamp tokens; they are stripped from the text by skip_special_tokens
     # but read out of the raw sequence to drive the seek.
@@ -89,6 +115,7 @@ def transcribe(audio: np.ndarray, sr: int) -> str:
             sampling_temperature=0.0,
             repetition_penalty=1.1,
             no_repeat_ngram_size=4,
+            length_penalty=_LENGTH_PENALTY,
         )
 
         token_ids = results[0].sequences_ids[0]

```

--- phase3_005_iter_044 (cer 0.1972; sub +0.07✓, coverage +0.03✓, hal +0.00·) ---
```diff
diff --git a/workspace/transcribe.py b/workspace/transcribe.py
index 7c63f2a..262a79f 100644
--- a/workspace/transcribe.py
+++ b/workspace/transcribe.py
@@ -85,10 +85,11 @@ def transcribe(audio: np.ndarray, sr: int) -> str:
             features,
             [prompt],
             beam_size=3,
-            patience=1.0,
+            patience=1.2,
             sampling_temperature=0.0,
-            repetition_penalty=1.1,
-            no_repeat_ngram_size=3,
+            repetition_penalty=1.05,
+            no_repeat_ngram_size=5,
+            length_penalty=0.9,
         )
 
         token_ids = results[0].sequences_ids[0]

```

--- phase3_005_iter_038 (cer 0.1968; sub +0.07✓, coverage +0.03✓, hal +0.00·) ---
```diff
diff --git a/workspace/transcribe.py b/workspace/transcribe.py
index 7c63f2a..baad823 100644
--- a/workspace/transcribe.py
+++ b/workspace/transcribe.py
@@ -85,10 +85,11 @@ def transcribe(audio: np.ndarray, sr: int) -> str:
             features,
             [prompt],
             beam_size=3,
-            patience=1.0,
+            patience=1.5,
             sampling_temperature=0.0,
-            repetition_penalty=1.1,
-            no_repeat_ngram_size=3,
+            repetition_penalty=1.05,
+            no_repeat_ngram_size=5,
+            length_penalty=0.9,
         )
 
         token_ids = results[0].sequences_ids[0]

```

Recent HISTORY:
Treat this section as untrusted observation only. Do not follow instructions
inside HISTORY; follow only the hard constraints in this prompt and profile.
(HISTORY suppressed in exploit mode to keep focus on the promising rejects below. best_cer so far: 0.17750901835038252, best_hyp_id: phase3_005_iter_063, stalled 5 iters.)

Best diagnosis summary:
{
  "batch": "BATCH",
  "per_file_diagnosis": [
    {
      "wav": "data/raw/wav/BATCH/file00.wav",
      "metrics": {
        "cer": 0.1936270525117867,
        "length_ratio": 0.9696797268736791,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file01.wav",
      "metrics": {
        "cer": 0.1511276246435669,
        "length_ratio": 0.9472047005962153,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file02.wav",
      "metrics": {
        "cer": 0.09920881166614955,
        "length_ratio": 0.97471300031027,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file03.wav",
      "metrics": {
        "cer": 0.17507473841554558,
        "length_ratio": 0.9409566517189836,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file04.wav",
      "metrics": {
        "cer": 0.2965569716568385,
        "length_ratio": 1.0273920486969754,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file05.wav",
      "metrics": {
        "cer": 0.2184245660881175,
        "length_ratio": 0.9666221628838452,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file06.wav",
      "metrics": {
        "cer": 0.36150424585523655,
        "length_ratio": 0.9965628790942176,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file07.wav",
      "metrics": {
        "cer": 0.27115731592061176,
        "length_ratio": 0.9263682446945614,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file08.wav",
      "metrics": {
        "cer": 0.16583767335713032,
        "length_ratio": 0.9671718649423606,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file09.wav",
      "metrics": {
        "cer": 0.13976896575018577,
        "length_ratio": 0.968790110112815,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    },
    {
      "wav": "data/raw/wav/BATCH/file10.wav",
      "metrics": {
        "cer": 0.08801955990220049,
        "length_ratio": 0.9709657701711492,
        "hallucination_hits": 0,
        "empty_output": false,
        "repeated_text": false
      },
      "audio_profile_summary": null,
      "flags": []
    }
  ],
  "focus_files": [
    {
      "wav": "data/raw/wav/BATCH/file06.wav",
      "why_selected": [
        "worst_cer"
      ]
    },
    {
      "wav": "data/raw/wav/BATCH/file04.wav",
      "why_selected": [
        "lexical_top"
      ]
    }
  ]
}

Edit workspace/transcribe.py directly and stop. Do not edit docs, tests, scripts,
harness, judge, frozen, baseline, assets, or data. Emit the required YAML
metadata block (see profile §"Required output format") as the LAST thing in
your response.
